# -*- coding: utf-8 -*-
"""
P_SPD_BASIS: 棕榈油期现基差 (DCE Palm Oil Spot-Futures Basis)
数据源: AKShare futures_spot_price(vars_list=["P"])
频率: 日度
说明: near_basis = spot_price - near_contract_price
注意: spot_price数据可能有较大滞后（实测20240430=7960元/吨，约2年前数据）
"""
import sys, os
this_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(this_dir, '..', 'common'))
from db_utils import save_to_db, get_latest_value
import akshare as ak
from datetime import date, timedelta
import pandas as pd

FACTOR_CODE = "P_SPD_BASIS"
SYMBOL = "P"
EXPECTED_MIN = -500
EXPECTED_MAX = 500
STALE_DAYS = 30  # 数据超过此天数视为过期

def fetch():
    df = ak.futures_spot_price(vars_list=["P"])
    if df.empty:
        raise ValueError("AKShare无P棕榈油基差数据")
    latest = df.sort_values('date').iloc[-1]
    raw_value = float(latest['near_basis'])
    obs_date = pd.to_datetime(latest['date']).date()
    return raw_value, obs_date

def main():
    try:
        raw_value, obs_date = fetch()
    except Exception as e:
        print("[L1] %s: %s" % (FACTOR_CODE, e))
        latest = get_latest_value(FACTOR_CODE, SYMBOL)
        if latest is not None:
            print("[L4FB] %s=%.1f" % (FACTOR_CODE, latest))
            return
        print("[SKIP] %s: no data" % FACTOR_CODE)
        return

    # 检查数据时效
    days_old = (date.today() - obs_date).days
    is_stale = days_old > STALE_DAYS
    if is_stale:
        print("[WARN] %s=%.1f obs=%s (滞后%d天)" % (FACTOR_CODE, raw_value, obs_date, days_old))
        print("[INFO] spot价格数据滞后，建议订阅MPOBA/月报实时数据")
        # 保存但降低置信度
        pub_date = date.today()
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, raw_value, source_confidence=0.6)
        return

    if not (EXPECTED_MIN <= raw_value <= EXPECTED_MAX):
        print("[WARN] %s=%.1f out of [%d,%d]" % (FACTOR_CODE, raw_value, EXPECTED_MIN, EXPECTED_MAX))
        return

    pub_date = date.today()
    save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, raw_value, source_confidence=1.0)
    print("[OK] %s=%.1f obs=%s" % (FACTOR_CODE, raw_value, obs_date))

if __name__ == "__main__":
    main()
