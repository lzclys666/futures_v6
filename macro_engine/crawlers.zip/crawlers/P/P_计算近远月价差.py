# -*- coding: utf-8 -*-
"""
P_SPD_CONTRACT: 棕榈油近远月价差 (DCE Palm Oil Near-Far Spread)
数据源: AKShare futures_spot_price(vars_list=["P"]) / futures_main_sina("P0")
频率: 日度
说明: 近月-远月期货价差
实测: near_basis=-250 (20240430)
"""
import sys, os
this_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(this_dir, '..', 'common'))
from db_utils import save_to_db, get_latest_value
import akshare as ak
from datetime import date
import pandas as pd

FACTOR_CODE = "P_SPD_CONTRACT"
SYMBOL = "P"
EXPECTED_MIN = -500
EXPECTED_MAX = 500

def fetch():
    df = ak.futures_spot_price(vars_list=["P"])
    if df.empty:
        raise ValueError("AKShare无P棕榈油近远月数据")
    latest = df.sort_values('date').iloc[-1]
    near = float(latest['near_contract_price'])
    dom = float(latest['dominant_contract_price'])
    raw_value = round(near - dom, 2)
    obs_date = pd.to_datetime(latest['date']).date()
    return raw_value, obs_date

def main():
    try:
        raw_value, obs_date = fetch()
    except Exception as e:
        print("[L1] %s: %s" % (FACTOR_CODE, e))
        latest = get_latest_value(FACTOR_CODE, SYMBOL)
        if latest is not None:
            print("[L4FB] %s=%.1f" % (FACTOR_CODE, latest))
            return
        print("[SKIP] %s: no data" % FACTOR_CODE)
        return

    if not (EXPECTED_MIN <= raw_value <= EXPECTED_MAX):
        print("[WARN] %s=%.1f out of [%d,%d]" % (FACTOR_CODE, raw_value, EXPECTED_MIN, EXPECTED_MAX))
        return

    pub_date = date.today()
    save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, raw_value, source_confidence=1.0)
    print("[OK] %s=%.1f obs=%s" % (FACTOR_CODE, raw_value, obs_date))

if __name__ == "__main__":
    main()
