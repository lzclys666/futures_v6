# -*- coding: utf-8 -*-
"""读取关键脚本样本"""
import os

samples = [
    ('AG', 'AG_抓取白银ETF持仓.py'),
    ('AU', 'AU_金银比_AUAG.py'),
    ('BR', 'BR_计算比价.py'),
    ('NR', 'NR_抓取BDI.py'),
    ('TA', 'TA_抓取PX价格.py'),
]

for v, fname in samples:
    path = os.path.join(r'D:\futures_v6\macro_engine\crawlers', v, fname)
    print(f'=== {v}/{fname} ===')
    for enc in ['utf-8', 'gbk']:
        try:
            with open(path, 'r', encoding=enc) as f:
                content = f.read()
            lines = content.split('\n')[:50]
            for l in lines:
                print(l)
            print()
            break
        except:
            pass
