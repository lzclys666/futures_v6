#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Y CBOT大豆油期货价格
Y_Y_FUT_CBOT_OIL

[跳过] 待开发
原因: AKShare接口待验证
数据层: L4

付费订阅: 如需激活此因子，请联系因子分析师配置付费数据源
"""
import sys
import datetime
from pathlib import Path

# 尝试导入通用模块
try:
    sys.path.insert(0, str(Path(__file__).parent.parent / 'common'))
    from io_win import fix_encoding
    fix_encoding()
except ImportError:
    pass

try:
    from common.db_utils import save_to_db, get_pit_dates
except ImportError:
    def save_to_db(*a, **kw): pass
    def get_pit_dates():
        today = datetime.date.today()
        dow = today.weekday()
        if dow == 0:
            obs = today - datetime.timedelta(days=3)
        elif dow >= 5:
            obs = today - datetime.timedelta(days=dow - 4)
        else:
            obs = today
        return obs, today

# 因子参数（在函数外捕获值）
_FACTOR_SYMBOL = "Y"
_FACTOR_CODE = "Y_FUT_CBOT_OIL"
_FACTOR_NAME = "CBOT大豆油期货价格"
_FACTOR_FC = "Y_Y_FUT_CBOT_OIL"
_FACTOR_REASON = "AKShare接口待验证"


def run(auto=False):
    obs_date, pub_date = get_pit_dates()
    print("[跳过] " + _FACTOR_FC + " = None (obs=" + str(obs_date) + ")")
    print("      原因: " + _FACTOR_REASON)

    if not auto:
        print('\n提示: 使用 --auto 参数可跳过此确认')

    # 写入 L4 stub 记录，value = None
    try:
        save_to_db(
            symbol=_FACTOR_SYMBOL,
            factor_code=_FACTOR_FC,
            obs_date=obs_date,
            pub_date=pub_date,
            raw_value=None,
            source="占位(付费订阅待配)",
            source_confidence=0.5,
            notes="[STUB] " + _FACTOR_REASON,
        )
        print("[OK] 已写入 stub 记录 (source_confidence=0.5)")
    except Exception as e:
        print("[WARN] DB写入失败: " + str(e))

    return 0


if __name__ == "__main__":
    auto = "--auto" in sys.argv
    sys.exit(run(auto=auto))
