#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AL_INV_SHFE - 沪铝上期所仓单
factor_code: AL_INV_SHFE
数据源: AKShare (L1免费)
"""
import sys, os as _os
sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), ".."))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value

import akshare as ak

FACTOR_CODE = "AL_INV_SHFE"
SYMBOL = "AL"

def fetch_shfe_receipt(obs_date):
    date_str = obs_date.strftime("%Y%m%d")
    try:
        print("[L1] AKShare futures_shfe_warehouse_receipt...")
        df = ak.futures_shfe_warehouse_receipt(date=date_str)
        if df is not None and len(df) > 0:
            cols = df.columns.tolist()
            al_col = None
            for c in cols:
                if 'al' in str(c).lower() or '铝' in str(c) or '铝' in str(c):
                    al_col = c; break
            if al_col is None:
                for c in cols:
                    if any(x in str(c) for x in ['仓单', '库存', '吨']):
                        al_col = c; break
                if al_col is None:
                    al_col = cols[-1]
            val = df.iloc[-1][al_col]
            if isinstance(val, str):
                val = val.replace(',', '').strip()
            val = float(val)
            if 0 <= val <= 5000000:
                print(f"[L1] 成功: {val:.0f} 吨")
                return val, 'akshare', 1.0
    except Exception as e:
        print(f"[L1] 失败: {e}")
    
    print("[L4] DB历史回补...")
    val = get_latest_value(FACTOR_CODE, SYMBOL)
    if val is not None:
        print(f"[L4] 兜底: {val}")
        return val, 'db_回补', 0.5
    return None, None, None

if __name__ == "__main__":
    pub_date, obs_date = get_pit_dates()
    if pub_date is None:
        print("非交易日，跳过"); exit(0)
    ensure_table()
    print(f"=== {FACTOR_CODE} === pub={pub_date} obs={obs_date}")
    value, source, confidence = fetch_shfe_receipt(obs_date)
    if value is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, value, source_confidence=confidence, source=source)
    else:
        print(f"[失败] {FACTOR_CODE} 所有数据源均失败")
