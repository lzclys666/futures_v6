#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AL_POS_NET - 沪铝净持仓
factor_code: AL_POS_NET
数据源: AKShare 上期所持仓排名 (L1免费)
"""
import sys, os as _os
sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), ".."))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value

import akshare as ak
import requests

FACTOR_CODE = "AL_POS_NET"
SYMBOL = "AL"

def fetch_net_position():
    try:
        print("[L1] AKShare get_shfe_rank_table...")
        df = ak.get_shfe_rank_table()
        if df is not None and len(df) > 0:
            al_df = df[df['variety'] == 'AL']
            if len(al_df) > 0:
                cols = al_df.columns.tolist()
                vol_col = None
                for c in cols:
                    if 'volume' in str(c).lower() or '成交量' in str(c):
                        vol_col = c; break
                if vol_col is None:
                    vol_col = cols[3] if len(cols) > 3 else cols[-1]
                net = float(al_df[vol_col].sum())
                if abs(net) < 10000000:
                    print(f"[L1] 成功: 前20净持仓={net:.0f} 手")
                    return net, 'akshare', 1.0
    except Exception as e:
        print(f"[L1] 失败: {e}")
    
    try:
        print("[L2] 新浪实时API...")
        headers = {'User-Agent': 'Mozilla/5.0'}
        resp = requests.get("http://hq.sinajs.cn/list=nf_AL0", headers=headers, timeout=10)
        resp.encoding = 'gbk'
        if resp.status_code == 200 and resp.text:
            data = resp.text.split('"')[1].split(',') if '"' in resp.text else []
            if len(data) >= 13:
                vol = float(data[11]) if data[11] else float(data[4])
                print(f"[L2] 成功: {vol:.0f} 手")
                return vol, 'sina', 0.9
    except Exception as e:
        print(f"[L2] 失败: {e}")
    
    print("[L4] DB历史回补...")
    val = get_latest_value(FACTOR_CODE, SYMBOL)
    if val is not None:
        print(f"[L4] 兜底: {val}")
        return val, 'db_回补', 0.5
    return None, None, None

if __name__ == "__main__":
    pub_date, obs_date = get_pit_dates()
    if pub_date is None:
        print("非交易日，跳过"); exit(0)
    ensure_table()
    print(f"=== {FACTOR_CODE} === pub={pub_date} obs={obs_date}")
    value, source, confidence = fetch_net_position()
    if value is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, value, source_confidence=confidence, source=source)
    else:
        print(f"[失败] {FACTOR_CODE} 所有数据源均失败")
