#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AL_SPD_BASIS - 沪铝期现基差
factor_code: AL_SPD_BASIS
数据源: AKShare 期货 + 现货L3(上海有色网/我的钢铁网付费)
"""
import sys, os as _os
sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), ".."))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value

import akshare as ak

FACTOR_CODE = "AL_SPD_BASIS"
SYMBOL = "AL"

def fetch_futures_price():
    try:
        print("[期货] AKShare futures_main_sina AL0...")
        df = ak.futures_main_sina(symbol="AL0")
        if df is not None and len(df) > 0:
            cols = df.columns.tolist()
            price_col = None
            for c in cols:
                if 'close' in str(c).lower() or '收盘' in str(c):
                    price_col = c; break
            if price_col is None:
                price_col = cols[4] if len(cols) > 4 else cols[-1]
            return float(df.iloc[-1][price_col])
    except Exception as e:
        print(f"[期货] 失败: {e}")
    return None

def fetch_spot_price():
    # L1: 上海有色网(SMM) - 付费
    print("[现货L1] 上海有色网 - 付费订阅，跳过")
    # L2: 我的钢铁网 - 付费
    print("[现货L2] 我的钢铁网 - 付费订阅，跳过")
    return None

def fetch_basis():
    futures = fetch_futures_price()
    if futures is None:
        print("[失败] 无法获取期货价格")
        return None, None, None
    print(f"  期货价格: {futures} 元/吨")
    
    spot = fetch_spot_price()
    if spot is not None:
        basis = spot - futures
        return basis, 'SMM/mysteel', 0.8
    
    print("[L4] DB历史基差回补...")
    val = get_latest_value(FACTOR_CODE, SYMBOL)
    if val is not None:
        print(f"[L4] 兜底: {val}")
        return val, 'db_回补', 0.5
    return None, None, None

if __name__ == "__main__":
    pub_date, obs_date = get_pit_dates()
    if pub_date is None:
        print("非交易日，跳过"); exit(0)
    ensure_table()
    print(f"=== {FACTOR_CODE} === pub={pub_date} obs={obs_date}")
    value, source, confidence = fetch_basis()
    if value is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, value, source_confidence=confidence, source=source)
    else:
        print(f"[失败] {FACTOR_CODE} 现货价需付费订阅")
