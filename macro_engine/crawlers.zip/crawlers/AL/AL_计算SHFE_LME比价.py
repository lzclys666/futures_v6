#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys

"""
SHFE/LME铝比价计算
factor_code: AL_SPD_SHFE_LME
含义: 内盘/外盘价格比值，反映内外价差
频率: 日频
数据源: 上期所主力 + LME铝期货价(铝道网爬取)
写入表: pit_factor_observations
"""

import sys
import os as _os
sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), ".."))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, DB_PATH

import akshare as ak
import datetime
import sqlite3

FACTOR_CODE = "AL_SPD_SHFE_LME"
SYMBOL = "AL"
LME_FACTOR_CODE = "AL_LME_PRICE"  # LME价格由AL_抓取LME铝价_铝道网.py写入本因子

def fetch_shfe_al_price():
    """获取上期所沪铝主力价格"""
    try:
        # 从结算价获取
        today = datetime.date.today().strftime("%Y%m%d")
        for i in range(5):
            date_str = (datetime.date.today() - datetime.timedelta(days=i)).strftime("%Y%m%d")
            try:
                df = ak.futures_settle_shfe(date=date_str)
                if df is not None and len(df) > 0:
                    al_df = df[df['variety'] == 'al'].sort_values('settle_price', ascending=False)
                    if len(al_df) > 0:
                        price = float(al_df.iloc[0]['settle_price'])
                        print(f"[SHFE] 沪铝主力: {price:.0f}元/吨 ({date_str})")
                        return price
            except:
                continue
    except Exception as e:
        print(f"[SHFE] 获取失败: {e}")
    return None

def fetch_lme_al_price_from_db(obs_date):
    """从数据库获取LME铝价格（由AL_抓取LME铝价_铝道网.py写入）"""
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        # 查找指定obs_date的LME价格
        cursor.execute("""
            SELECT raw_value FROM pit_factor_observations 
            WHERE factor_code = ? AND obs_date = ?
            ORDER BY pub_date DESC LIMIT 1
        """, (LME_FACTOR_CODE, obs_date))
        
        result = cursor.fetchone()
        conn.close()
        
        if result:
            price = float(result[0])
            print(f"[LME] 从数据库获取: {price}美元/吨 (obs_date={obs_date})")
            return price
        else:
            print(f"[LME] 数据库中未找到obs_date={obs_date}的价格")
            return None
            
    except Exception as e:
        print(f"[LME] 数据库查询失败: {e}")
        return None

def manual_input_shfe_lme_ratio():
    """手动输入SHFE/LME比价"""
    print("\n" + "=" * 50)
    print("手动输入模式 - SHFE/LME铝比价")
    print("=" * 50)
    print("数据来源：上期所官网 + LME官网")
    print("提示：比值 = SHFE价/(LME价×汇率)")
    print("输入 0 跳过\n")

    try:
        shfe_price = input("请输入SHFE沪铝主力价（元/吨）: ").strip()
        lme_price = input("请输入LME铝价格（美元/吨）: ").strip()
        fx_rate = input("请输入USD/CNY汇率（如7.20）: ").strip()
        
        if all([shfe_price, lme_price, fx_rate]) and all(p != "0" for p in [shfe_price, lme_price, fx_rate]):
            ratio = float(shfe_price) / (float(lme_price) * float(fx_rate))
            print("[手动] SHFE/LME比价={:.4f}".format(ratio))
            return ratio
    except ValueError:
        print("[手动] 输入格式错误")
    return None

if __name__ == "__main__":
    pub_date, obs_date = get_pit_dates()
    if pub_date is None:
        print("周日非交易日，跳过")
        exit(0)

    ensure_table()

    print(f"=== SHFE/LME铝比价计算 ===")
    print(f"发布日期(pub_date): {pub_date}")
    print(f"观测日期(obs_date): {obs_date}")

    shfe_price = fetch_shfe_al_price()
    lme_price = fetch_lme_al_price_from_db(obs_date)
    is_auto = "--auto" in sys.argv

    if shfe_price is not None and lme_price is not None:
        # 正确比价 = SHFE(CNY/kg) / (LME_USD/ton * FX / 1000) = SHFE * 1000 / (LME * FX)
        # 或直接: SHFE_CNY_kg / (LME_USD_ton * FX) * 1000
        # 简化: 比值 = SHFE(25525) / (LME(3635) * FX(7.2)) ≈ 0.975
        ratio = round(shfe_price / (lme_price * 7.2), 4)
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, ratio, source_confidence=0.85)
        print(f"[自动] SHFE/LME铝比价已写入: {ratio:.4f} (SHFE={shfe_price:.0f}CNY/kg, LME={lme_price}USD/ton, FX=7.2)")
    elif not is_auto:
        ratio = manual_input_shfe_lme_ratio()
        if ratio is not None:
            save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, ratio, source_confidence=0.6)
            print(f"[手动] SHFE/LME铝比价已写入: {ratio:.2f}")
    else:
        print("[自动模式] 数据源均失败，跳过写入")

    print("===== 任务完成 =====")
