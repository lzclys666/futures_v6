#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AL_SPD_AL_CU - 沪铝铜比价
factor_code: AL_SPD_AL_CU
数据源: AKShare (L1免费)
"""
import sys, os as _os
sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), ".."))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value

import akshare as ak
import requests

FACTOR_CODE = "AL_SPD_AL_CU"
SYMBOL = "AL"

def fetch_ratio():
    try:
        print("[L1] 新浪实时API AL0 & CU0...")
        headers = {'User-Agent': 'Mozilla/5.0'}
        resp = requests.get("http://hq.sinajs.cn/list=nf_AL0,nf_CU0", headers=headers, timeout=10)
        resp.encoding = 'gbk'
        if resp.status_code == 200 and resp.text:
            lines = resp.text.strip().split('\n')
            prices = []
            for line in lines:
                if '"' in line:
                    parts = line.split('"')[1].split(',')
                    if len(parts) >= 5:
                        prices.append(float(parts[4]))
            if len(prices) >= 2 and prices[1] > 0:
                ratio = prices[0] / prices[1]
                print(f"[L1] 成功: AL/CU={ratio:.4f} (AL={prices[0]:.0f}, CU={prices[1]:.0f})")
                return ratio, 'sina', 1.0
    except Exception as e:
        print(f"[L1] 失败: {e}")
    
    try:
        print("[L2] AKShare futures_zh_daily_sina...")
        df_al = ak.futures_zh_daily_sina(symbol="AL0")
        df_cu = ak.futures_zh_daily_sina(symbol="CU0")
        if df_al is not None and df_cu is not None:
            p_al = float(df_al.iloc[-1]['close'])
            p_cu = float(df_cu.iloc[-1]['close'])
            if p_cu > 0:
                ratio = p_al / p_cu
                print(f"[L2] 成功: AL/CU={ratio:.4f}")
                return ratio, 'akshare', 0.9
    except Exception as e:
        print(f"[L2] 失败: {e}")
    
    print("[L4] DB历史回补...")
    val = get_latest_value(FACTOR_CODE, SYMBOL)
    if val is not None:
        print(f"[L4] 兜底: {val}"); return val, 'db_回补', 0.5
    return None, None, None

if __name__ == "__main__":
    pub_date, obs_date = get_pit_dates()
    if pub_date is None:
        print("非交易日，跳过"); exit(0)
    ensure_table()
    print(f"=== {FACTOR_CODE} === pub={pub_date} obs={obs_date}")
    value, source, confidence = fetch_ratio()
    if value is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, value, source_confidence=confidence, source=source)
    else:
        print(f"[失败] {FACTOR_CODE} 所有数据源均失败")
