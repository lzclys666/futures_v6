#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AL_INV_LME - LME铝库存
factor_code: AL_INV_LME
数据源: AKShare (L1免费)
"""
import sys, os as _os
sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), ".."))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value

import akshare as ak

FACTOR_CODE = "AL_INV_LME"
SYMBOL = "AL"

def fetch_lme_inventory():
    # L1: macro_euro_lme_stock (欧洲LME库存)
    try:
        print("[L1] AKShare macro_euro_lme_stock...")
        df = ak.macro_euro_lme_stock()
        if df is not None and len(df) > 0:
            cols = df.columns.tolist()
            # 查找铝相关列
            al_col = None
            for c in cols:
                if 'aluminum' in str(c).lower() or 'al' in str(c).lower():
                    al_col = c; break
            if al_col is None:
                al_col = cols[-1]
            val = df.iloc[-1][al_col]
            if isinstance(val, str):
                val = val.replace(',', '').strip()
            val = float(val)
            if 0 <= val <= 10000000:
                print(f"[L1] 成功: {val:.0f} 吨")
                return val, 'akshare', 1.0
    except Exception as e:
        print(f"[L1] 失败: {e}")
    
    # L2: 尝试LME官网爬取
    try:
        print("[L2] LME官网...")
        import requests
        headers = {'User-Agent': 'Mozilla/5.0'}
        # LME官网铝库存页面
        url = "https://www.lme.com/en/metals/aluminium/"
        resp = requests.get(url, headers=headers, timeout=15)
        if resp.status_code == 200:
            print(f"[L2] LME页面获取成功({len(resp.text)}字符)，解析中...")
            # TODO: 解析LME铝库存数据
    except Exception as e:
        print(f"[L2] 失败: {e}")
    
    # L4: DB回补
    print("[L4] DB历史回补...")
    val = get_latest_value(FACTOR_CODE, SYMBOL)
    if val is not None:
        print(f"[L4] 兜底: {val}")
        return val, 'db_回补', 0.5
    return None, None, None

if __name__ == "__main__":
    pub_date, obs_date = get_pit_dates()
    if pub_date is None:
        print("非交易日，跳过"); exit(0)
    ensure_table()
    print(f"=== {FACTOR_CODE} === pub={pub_date} obs={obs_date}")
    value, source, confidence = fetch_lme_inventory()
    if value is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, value, source_confidence=confidence, source=source)
    else:
        print(f"[失败] {FACTOR_CODE} 所有数据源均失败")
