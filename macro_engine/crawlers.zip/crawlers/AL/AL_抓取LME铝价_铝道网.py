#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AL_抓取LME铝价_铝道网.py - 从铝道网获取LME铝现货价格

数据源: https://hq.alu.cn/lmeld.html
数据类型: LME铝现货结算价（美元/吨）
"""

import sys
import os
import re
import sqlite3
import requests
from datetime import datetime, timedelta

# 添加项目根目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

from common.db_utils import ensure_table, save_to_db, get_pit_dates, DB_PATH

# 配置
FACTOR_CODE = 'AL_LME_PRICE'
FACTOR_NAME = 'LME铝现货价'
DATA_SOURCE = '铝道网(hq.alu.cn)'

# 铝道网URL
URL = 'https://hq.alu.cn/lmeld.html'

def fetch_lme_aluminum_price():
    """
    从铝道网获取LME铝现货价格
    
    Returns:
        dict: {'date': 'YYYY-MM-DD', 'price': float, 'source': str}
        None: 获取失败
    """
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        }
        
        print(f"正在请求: {URL}")
        resp = requests.get(URL, headers=headers, timeout=15)
        resp.encoding = 'gb2312'
        
        if resp.status_code != 200:
            print(f"HTTP请求失败: {resp.status_code}")
            return None
        
        html = resp.text
        
        # 策略1: 从标题获取最新日期和价格
        # 格式: 2026年04月16日LME伦敦金属交易所现货行情价3618
        title_match = re.search(r'(\d{4})年(\d{2})月(\d{2})日LME.*?现货行情价([\d.]+)', html)
        if title_match:
            year, month, day, price = title_match.groups()
            date_str = f"{year}-{month}-{day}"
            price_val = float(price)
            print(f"从标题解析: 日期={date_str}, 价格={price_val}")
            return {
                'date': date_str,
                'price': price_val,
                'source': DATA_SOURCE
            }
        
        # 策略2: 从历史表格获取最新数据
        # 查找表格行
        table_rows = re.findall(r'<tr[^>]*>(.*?)</tr>', html, re.DOTALL)
        
        for row in table_rows:
            cells = re.findall(r'<td[^>]*>(.*?)</td>', row, re.DOTALL)
            cells = [re.sub(r'<[^>]+>', '', c).strip() for c in cells]
            
            # 检查是否是LME铝数据行
            if len(cells) >= 6 and 'LME' in cells[1] and '铝' in cells[1]:
                # cells: [日期, 品种, 收盘价, 最高价, 最低价, 均价]
                date_cell = cells[0]  # 格式: 04-16
                close_price = cells[2]  # 收盘价
                
                # 转换日期格式
                current_year = datetime.now().year
                if '-' in date_cell:
                    month, day = date_cell.split('-')
                    date_str = f"{current_year}-{month}-{day}"
                else:
                    continue
                
                try:
                    price_val = float(close_price)
                    print(f"从表格解析: 日期={date_str}, 价格={price_val}")
                    return {
                        'date': date_str,
                        'price': price_val,
                        'source': DATA_SOURCE
                    }
                except ValueError:
                    continue
        
        print("未能从页面解析出LME铝价")
        return None
        
    except requests.exceptions.RequestException as e:
        print(f"网络请求异常: {e}")
        return None
    except Exception as e:
        print(f"解析异常: {e}")
        return None

def main():
    """主函数"""
    ensure_table()
    
    pub_date, obs_date = get_pit_dates()
    if pub_date is None:
        print("周日非交易日，跳过")
        return 0
    
    print(f"=== {FACTOR_CODE} ===")
    print(f"pub_date: {pub_date}")
    print(f"obs_date: {obs_date}")
    
    # 获取LME铝价
    data = fetch_lme_aluminum_price()
    
    if data:
        # 保存到数据库
        save_to_db(FACTOR_CODE, 'AL', pub_date, obs_date, data['price'], 
                  source_confidence=1.0, source=DATA_SOURCE)
        print(f"✅ 数据已保存: {FACTOR_CODE} = {data['price']} ({obs_date})")
        return 0
    else:
        print(f"❌ {FACTOR_CODE} 抓取失败")
        return 1

if __name__ == '__main__':
    sys.exit(main())
