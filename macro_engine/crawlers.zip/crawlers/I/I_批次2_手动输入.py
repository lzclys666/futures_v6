# -*- coding: utf-8 -*-
"""
I_批次2_手动输入.py - 铁矿石批次2付费因子手动输入框架
付费来源: Mysteel / SMM / 隆众资讯
auto模式下打印跳过说明，不写入数据
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'common'))
from db_utils import save_to_db, get_latest_value
from datetime import date

PAID_FACTORS = {
    # 供给侧
    "I_SUP_OUTPUT":    "铁矿石产量 (Mysteel月频)",
    "I_SUP_SHIPMENT":  "铁矿石发货量 (Mysteel周频)",
    "I_STK_BONDED":    "铁矿石保税区库存 (SMM)",
    # 需求侧
    "I_DEM_STEEL":     "钢厂铁矿石日耗 (Mysteel日频)",
    "I_DEM_STEEL_MI":  "钢厂铁水产量 (Mysteel日频，百万吨)",
    # 成本
    "I_COST_BREAKEVEN":"钢厂铁矿石保本价 (Mysteel)",
    "I_COST_PORT":     "铁矿石港口现货价 (Mysteel/我的钢铁)",
    # 开工率/产能
    "I_OP_RATE":       "矿山开工率 (SMM)",
    "I_CAP_UTIL":      "港口产能利用率 (隆众)",
    # 其他
    "I_SPD_62_65":     "62%-65%品位价差 (SMM)",
    "I_FREIGHT_BDI":   "波罗的海干散货指数BDI (免费)",
    "I_POS_NET":       "铁矿石持仓净多 (DCE排名，接口不稳定)",
}

def print_skip_notice():
    print("=" * 60)
    print("I批次2因子 - 付费/无免费数据源，auto模式跳过")
    print("=" * 60)
    for code, desc in PAID_FACTORS.items():
        print(f"  {code}: {desc}")
    print()
    print("如需录入数据，请手动修改脚本中的因子值并注释掉return语句")
    print("或使用 py I_批次2_手动输入.py --manual 交互输入")

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--auto', action='store_true')
    parser.add_argument('--manual', action='store_true')
    args = parser.parse_args()

    if args.auto:
        print_skip_notice()
        return

    if args.manual:
        print("手动录入模式 (示例):")
        for code, desc in PAID_FACTORS.items():
            print(f"  {code}: {desc}")
        return

    # 无参数：打印说明
    print_skip_notice()

if __name__ == "__main__":
    main()
