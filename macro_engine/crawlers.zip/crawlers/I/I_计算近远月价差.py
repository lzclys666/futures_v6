# -*- coding: utf-8 -*-
"""
I_SPD_CONTRACT: 铁矿石近远月价差 (DCE Iron Ore Near-Far Month Spread)
数据源: AKShare futures_spot_price(date, vars_list=['I'])
频率: 日度
说明: 近月-远月价差，用AKShare的near_contract和dominant_contract的结算价差
实测2026-04-18: near_contract=i2505(751.5), dominant_contract=i2509(699.0), spread=52.5
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'common'))
from db_utils import save_to_db, get_latest_value
import akshare as ak
from datetime import date, timedelta

FACTOR_CODE = "I_SPD_CONTRACT"
SYMBOL = "I"
EXPECTED_MIN = -50
EXPECTED_MAX = 100

def get_last_trading_day():
    today = date.today()
    for days_back in range(7):
        d = today - timedelta(days=days_back)
        if d.weekday() < 5:
            return d
    return today

def fetch():
    obs_date = get_last_trading_day()
    date_str = obs_date.strftime('%Y%m%d')
    df = ak.futures_spot_price(date=date_str, vars_list=['I'])
    if df.empty:
        raise ValueError(f"I现货价返回空 date={date_str}")
    row = df.iloc[0]
    near_price = float(row['near_contract_price'])
    dom_price = float(row['dominant_contract_price'])
    raw_value = near_price - dom_price
    return raw_value, obs_date

def main():
    try:
        raw_value, obs_date = fetch()
    except Exception as e:
        print(f"[L1 FAIL] {FACTOR_CODE}: {e}")
        latest = get_latest_value(FACTOR_CODE, SYMBOL)
        if latest is not None:
            print(f"[L4 Fallback] {FACTOR_CODE}={latest}")
            return
        print(f"[L4 SKIP] {FACTOR_CODE}: no data")
        return

    if not (EXPECTED_MIN <= raw_value <= EXPECTED_MAX):
        print(f"[WARN] {FACTOR_CODE}={raw_value} out of [{EXPECTED_MIN},{EXPECTED_MAX}]")
        return

    pub_date = date.today()
    save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, raw_value, source_confidence=1.0)
    print(f"[OK] {FACTOR_CODE}={raw_value} obs={obs_date}")

if __name__ == "__main__":
    main()
