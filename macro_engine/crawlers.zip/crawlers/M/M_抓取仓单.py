#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
M_抓取仓单.py — CZCE豆粕注册仓单

因子: M_STK_WARRANT = CZCE豆粕(M)注册仓单

⚠️ 永久跳过说明（2026-04-19）：
  CZCE豆粕(M)采用厂库交割制度，无传统仓库仓单数据。
  AKShare futures_warehouse_receipt_czce() 无 M 数据。
  历史数据 RM(菜粕) ≠ M(豆粕)，不可混用。
  
  替代方案：
  - 隆众资讯年费（豆粕工厂库存+厂库仓单）
  - Mysteel年费（豆粕周度库存）
  - USDA月报（大豆压榨+豆粕库存）

数据源: 无免费源 → 永久跳过
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.db_utils import ensure_table, get_pit_dates

FACTOR_CODE = "M_STK_WARRANT"
SYMBOL = "M"


def main():
    ensure_table()
    pub_date, obs_date = get_pit_dates(freq="日频")
    if obs_date is None:
        print("非交易日，跳过")
        return 0

    print(f"=== {FACTOR_CODE} === obs={obs_date}")
    print("[L1-4] CZCE豆粕(M)无免费仓单数据（厂库交割制度）")
    print("[永久跳过] 建议订阅隆众资讯或Mysteel获取豆粕库存数据")
    print(f"{FACTOR_CODE}: SKIP(无免费源)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
