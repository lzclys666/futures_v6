# -*- coding: utf-8 -*-
"""
NR_STK_WARRANT: 天然橡胶NR注册仓单 (NR Warehouse Receipts)
注意: INE(国际铜交易中心)无公开WRT接口，NR_INV_TOTAL已覆盖INE库存
此因子永久SKIP，数据需求请联系INE付费数据
"""
import sys, os
this_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(this_dir, '..', 'common'))
from db_utils import save_to_db, get_latest_value
from datetime import date

FACTOR_CODE = "NR_STK_WARRANT"
SYMBOL = "NR"

def main():
    print("[SKIP] NR_STK_WARRANT: INE无公开仓单数据，NR_INV_TOTAL已覆盖")
    latest = get_latest_value(FACTOR_CODE, SYMBOL)
    if latest is not None:
        print("[L4FB] %s=%.0f" % (FACTOR_CODE, latest))
    else:
        print("[SKIP] NR_STK_WARRANT: no data")

if __name__ == "__main__":
    main()
