# -*- coding: utf-8 -*-
"""
NR_SPD_BASIS: 天然橡胶期现基差
永久跳过: AKShare无NR(20号胶)现货价格，RU(天然橡胶)现货NR现货
如需基差，请使用RU_SPD_BASIS作为参考
"""
import sys, os
this_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(this_dir, '..', 'common'))
from db_utils import save_to_db, get_latest_value
from datetime import date

FACTOR_CODE = "NR_SPD_BASIS"
SYMBOL = "NR"

def main():
    print("[SKIP] NR_SPD_BASIS: AKShare无NR(20号胶)现货价格")
    latest = get_latest_value(FACTOR_CODE, SYMBOL)
    if latest is not None:
        print("[L4FB] %s=%.0f" % (FACTOR_CODE, latest))
    else:
        print("[SKIP] NR_SPD_BASIS: no data")

if __name__ == "__main__":
    main()
