#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SA_抓取纯碱库存_em.py
因子: sa_inventory_w (纯碱库存/社会库存)
数据源: L1=AKShare futures_inventory_em(纯碱社会库存)
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, save_l4_fallback, get_latest_value
import akshare as ak

FACTOR_CODE = "sa_inventory_w"
SYMBOL = "SA"

def fetch():
    print("[L1] AKShare futures_inventory_em(纯碱)...")
    try:
        df = ak.futures_inventory_em(symbol="纯碱")
        if df is not None and len(df) > 0:
            row = df.iloc[-1]
            val = float(row.iloc[1])  # 今日库存
            print(f"[L1] SA纯碱库存: {val} 吨  (日变化: {row.iloc[2]})")
            return val
    except Exception as e:
        print(f"[L1] 失败: {e}")
    return None

def main():
    import argparse
    ensure_table()
    pub_date, obs_date = get_pit_dates()
    print(f"(auto) === {FACTOR_CODE} === obs={obs_date}")
    val = fetch()
    if val is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, val, source_confidence=1.0, source="akshare_futures_inventory_em")
        print(f"✅ {FACTOR_CODE}={val} 写入成功")
    else:
        ok = save_l4_fallback(FACTOR_CODE, SYMBOL, pub_date, obs_date)
        if ok:
            print(f"[OK] {FACTOR_CODE} L4回补成功")
        else:
            print(f"[SKIP] {FACTOR_CODE} 今日已有数据或无历史值")

if __name__ == "__main__":
    main()
