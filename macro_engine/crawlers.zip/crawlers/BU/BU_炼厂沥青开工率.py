#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BU 沥青炼厂开工率
BU_BU_STK_REFINE_RATE

数据源:
  - L1: 无免费数据源
  - L4: DB历史回补

备注: 炼厂开工率需隆众资讯付费账号，暂时无法获取。
      替代方案(Brent开工率)暂不可实现，待付费账号就绪。
"""
import sys, os as _os
sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), ".."))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value

FACTOR_CODE = "BU_BU_STK_REFINE_RATE"
SYMBOL = "BU"

def fetch_refine_rate():
    print("[NOTE] Refinery utilization rate has no free data source, needs paid Longzhong account")
    print("[L4] DB history fallback...")
    val = get_latest_value(FACTOR_CODE, SYMBOL)
    if val is not None:
        print(f"[L4] Fallback: {val}")
        return val, 'db_fallback', 0.5
    return None, None, None

if __name__ == "__main__":
    pub_date, obs_date = get_pit_dates()
    ensure_table()
    print(f"=== {FACTOR_CODE} === pub={pub_date} obs={obs_date}")
    value, source, confidence = fetch_refine_rate()
    if value is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, value, source_confidence=confidence, source=source)
    else:
        print(f"[SKIP] {FACTOR_CODE} no history to fall back to")
