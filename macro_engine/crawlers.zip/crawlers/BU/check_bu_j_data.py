import sqlite3
conn = sqlite3.connect('D:/futures_v6/macro_engine/pit_data.db')
cursor = conn.cursor()

cursor.execute("SELECT factor_code, symbol, obs_date, raw_value, source, source_confidence FROM pit_factor_observations WHERE symbol='BU' AND raw_value IS NOT NULL ORDER BY obs_date DESC, factor_code LIMIT 20")
bu_rows = cursor.fetchall()
print('=== BU Recent Data ===')
for row in bu_rows:
    print(f'  {row[0]} | {row[1]} | {row[2]} | {row[3]} | {row[4]} | conf={row[5]}')

cursor.execute("SELECT factor_code, symbol, obs_date, raw_value, source, source_confidence FROM pit_factor_observations WHERE symbol='J' AND raw_value IS NOT NULL ORDER BY obs_date DESC, factor_code LIMIT 20")
j_rows = cursor.fetchall()
print()
print('=== J Recent Data ===')
for row in j_rows:
    print(f'  {row[0]} | {row[1]} | {row[2]} | {row[3]} | {row[4]} | conf={row[5]}')

cursor.execute("SELECT COUNT(*) FROM pit_factor_observations WHERE symbol='BU' AND raw_value IS NOT NULL")
bu_count = cursor.fetchone()[0]
cursor.execute("SELECT COUNT(*) FROM pit_factor_observations WHERE symbol='J' AND raw_value IS NOT NULL")
j_count = cursor.fetchone()[0]
cursor.execute("SELECT COUNT(DISTINCT factor_code) FROM pit_factor_observations WHERE symbol='BU' AND raw_value IS NOT NULL")
bu_factors = cursor.fetchone()[0]
cursor.execute("SELECT COUNT(DISTINCT factor_code) FROM pit_factor_observations WHERE symbol='J' AND raw_value IS NOT NULL")
j_factors = cursor.fetchone()[0]
print()
print(f'BU factors: {bu_factors}, total rows: {bu_count}')
print(f'J factors: {j_factors}, total rows: {j_count}')
conn.close()
