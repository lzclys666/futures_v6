#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AG_抓取COMEX白银库存.py
因子: AG_INV_COMEX_SILVER (COMEX白银库存)
数据源: L1=AKShare futures_comex_inventory()
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value
import akshare as ak

FACTOR_CODE = "AG_INV_COMEX_SILVER"
SYMBOL = "AG"

def fetch():
    print("[L1] AKShare futures_comex_inventory...")
    try:
        df = ak.futures_comex_inventory()
        if df is not None and len(df) > 0:
            row = df.iloc[-1]
            # COMEX白银库存（吨）
            val = float(row.iloc[2])
            print(f"[L1] COMEX白银库存={val}吨")
            return val
    except Exception as e:
        print(f"[L1] 失败: {e}")
    return None

def main():
    import argparse
    ensure_table()
    pub_date, obs_date = get_pit_dates()
    print(f"(auto) === {FACTOR_CODE} === obs={obs_date}")
    val = fetch()
    if val is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, val, source_confidence=1.0, source="akshare_comex_inventory")
        print(f"✅ {FACTOR_CODE}={val} 写入成功")
    else:
        v = get_latest_value(FACTOR_CODE, SYMBOL)
        if v is not None:
            save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, v, source_confidence=0.5, source="db_回补")
            print(f"✅ {FACTOR_CODE}={v} L4回补成功")

if __name__ == "__main__":
    main()
