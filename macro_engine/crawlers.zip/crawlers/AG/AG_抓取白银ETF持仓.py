#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AG_抓取白银ETF持仓.py
因子: AG_DEM_ETF_HOLDING (白银ETF持仓量)
数据源: L1=AKShare macro_cons_silver(白银消费/ETF数据) → L4回补
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value
import akshare as ak

FACTOR_CODE = "AG_DEM_ETF_HOLDING"
SYMBOL = "AG"

def fetch():
    print("[L1] AKShare macro_cons_silver...")
    try:
        df = ak.macro_cons_silver()
        if df is not None and len(df) > 0:
            print(df.columns.tolist())
            print(df.tail(3))
    except Exception as e:
        print(f"[L1] 失败: {e}")
    print("[L4] DB历史回补...")
    return get_latest_value(FACTOR_CODE, SYMBOL)

def main():
    import argparse
    ensure_table()
    pub_date, obs_date = get_pit_dates()
    print(f"(auto) === {FACTOR_CODE} === obs={obs_date}")
    val = fetch()
    if val is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, val, source_confidence=0.5, source="db_回补")
        print(f"✅ {FACTOR_CODE}={val} L4回补成功")

if __name__ == "__main__":
    main()
