#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AG_抓取现货价.py
因子: AG_SPD_BASIS (白银基差)
数据源: L1=AKShare futures_spot_price(AG现货+基差)
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value
import akshare as ak
import pandas as pd

SYMBOL = "AG"

def fetch(obs_date):
    print("[L1] AKShare futures_spot_price AG...")
    date_str = obs_date.strftime("%Y%m%d")
    df = ak.futures_spot_price(date=date_str, vars_list=["AG"])
    if df is None or len(df) == 0:
        return {}
    row = df.iloc[-1]
    result = {}
    val = float(row["spot_price"])
    result["AG_SPD_BASIS"] = val
    print(f"[L1] AG现货价={val}")
    return result

def main():
    import argparse
    ensure_table()
    pub_date, obs_date = get_pit_dates()
    print(f"(auto) === AG现货 === obs={obs_date}")
    vals = fetch(obs_date)
    for fc, val in vals.items():
        save_to_db(fc, SYMBOL, pub_date, obs_date, val, source_confidence=1.0, source="akshare_futures_spot_price")
        print(f"[OK] {fc}={val} 写入成功")

if __name__ == "__main__":
    main()
