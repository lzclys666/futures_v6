#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value
import akshare as ak
import requests

SYMBOL = "AG"

def fetch_usd_cny():
    """获取USD/CNY即期汇率（新浪）"""
    try:
        r = requests.get(
            'https://hq.sinajs.cn/list=USDCNY,USDCNH',
            headers={'User-Agent': 'Mozilla/5.0', 'Referer': 'https://finance.sina.com.cn'},
            timeout=10
        )
        r.encoding = 'utf-8'
        for line in r.text.strip().split('\n'):
            if 'USDCNY' in line and 'pv_none' not in line:
                parts = line.split('"')[1].split(',')
                if len(parts) > 1:
                    return float(parts[1])
    except Exception as e:
        print(f"  汇率获取失败: {e}")
    return None

def main():
    ensure_table()
    pub_date, obs_date = get_pit_dates()
    obs_str = obs_date.strftime("%Y-%m-%d")
    print(f"(auto) === AG沪银/COMEX银比价 === obs={obs_date}")

    close_col = lambda df: [c for c in df.columns if '收盘' in str(c) or '最新' in str(c)][0]

    def get_close(df, obs):
        col = close_col(df)
        matches = df[df['日期'] == obs][col]
        if len(matches) > 0:
            return float(matches.iloc[0])
        return float(df.iloc[-1][col])

    # ----- L1: SHFE AG + COMEX SI + 汇率 -----
    ag_df = None
    si_df = None
    try:
        ag_df = ak.futures_main_sina("AG0")
        si_df = ak.futures_main_sina("SI0")
        rate = fetch_usd_cny()

        if ag_df is not None and len(ag_df) > 0:
            ag_close = get_close(ag_df, obs_str)
            print(f"  沪银AG: {ag_close} 元/kg")
        else:
            print("  沪银AG无数据"); ag_close = None

        if si_df is not None and len(si_df) > 0:
            si_close = get_close(si_df, obs_str)
            # AKShare返回COMEX数据单位: 美分/oz
            # 1 oz = 31.1035g → 1 kg = 1000/31.1035 oz = 32.1507 oz
            si_cny_kg = si_close / 100 * rate / 31.1035 * 1000  # 美分/oz → 美元/oz → 美元/kg
            si_cny_kg = si_close / 100 * rate / 31.1035 * 1000
            # 简写: SI_close(美分) × 汇率 × 32.1507 / 100 = CNY/kg
            si_cny_kg_v2 = si_close * rate * 0.321507  # 美元/kg
            print(f"  COMEX SI: {si_close} 美分/oz = {si_cny_kg_v2:.2f} 元/kg (汇率={rate})")
        else:
            print("  COMEX SI无数据"); si_close = None

        if ag_close and si_close and rate:
            si_cny_kg = si_close * rate * 0.321507
            ratio = round(ag_close / si_cny_kg, 4)
            print(f"  比价: {ag_close} / {si_cny_kg:.2f} = {ratio}")
            save_to_db("AG_SPD_SHFE_COMEX", SYMBOL, pub_date, obs_date, ratio,
                       source_confidence=1.0, source="akshare_futures_main_sina+新浪汇率")
            print(f">>> AG_SPD_SHFE_COMEX={ratio} 写入成功")
            return
    except Exception as e:
        print(f"[L1] 失败: {e}")

    # ----- L4: 历史回补 -----
    val = get_latest_value("AG_SPD_SHFE_COMEX", SYMBOL)
    if val is not None:
        save_to_db("AG_SPD_SHFE_COMEX", SYMBOL, pub_date, obs_date, val, source_confidence=0.5, source="db_回补")
        print(f">>> AG_SPD_SHFE_COMEX={val} L4回补成功")
    else:
        print("FAIL: 所有数据源均失败")

if __name__ == "__main__":
    main()
