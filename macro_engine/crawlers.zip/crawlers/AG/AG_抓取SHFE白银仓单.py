#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AG_抓取SHFE白银仓单.py
因子: AG_INV_SHFE_AG (SHFE白银仓单)
数据源: L1=AKShare futures_shfe_warehouse_receipt → 失效
L2=AKShare futures_spot_stock(symbol='AG') → L4回补
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value
import akshare as ak

FACTOR_CODE = "AG_INV_SHFE_AG"
SYMBOL = "AG"

def fetch():
    print("[L1] AKShare futures_shfe_warehouse_receipt(AG)...")
    try:
        df = ak.futures_shfe_warehouse_receipt(symbol="AG")
        if df is not None and len(df) > 0:
            print(df.head(3))
            # 取合计/总计行
            for _, row in df.iterrows():
                if "合计" in str(row.iloc[0]) or "总计" in str(row.iloc[0]):
                    val = float(row.iloc[-1])
                    print(f"[L1] SHFE白银仓单={val}")
                    return val
    except Exception as e:
        print(f"[L1] 失败: {e}")
    print("[L4] DB历史回补...")
    return get_latest_value(FACTOR_CODE, SYMBOL)

def main():
    import argparse
    ensure_table()
    pub_date, obs_date = get_pit_dates()
    print(f"(auto) === {FACTOR_CODE} === obs={obs_date}")
    val = fetch()
    if val is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, val, source_confidence=1.0, source="akshare_shfe_warehouse")
        print(f"✅ {FACTOR_CODE}={val} 写入成功")
    else:
        print(f"⚠️  {FACTOR_CODE} 无数据源")

if __name__ == "__main__":
    main()
