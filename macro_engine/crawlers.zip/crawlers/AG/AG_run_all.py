#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AG_run_all.py - 白银数据采集总调度"""
import os, sys, subprocess, time
from datetime import datetime

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
sys.stderr.reconfigure(encoding='utf-8', errors='replace')

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(SCRIPT_DIR)

SCRIPTS = [
    "AG_抓取现货价.py",
    "AG_抓取期货日行情.py",
    "AG_抓取COMEX白银库存.py",
    "AG_抓取SHFE白银仓单.py",
    "AG_抓取净持仓.py",
    "AG_抓取CFTC白银持仓.py",
    "AG_抓取美元指数.py",
    "AG_抓取黄金白银比.py",
    "AG_抓取CPI.py",
    "AG_抓取TIPS.py",
    "AG_抓取汇率.py",
    "AG_抓取黄金白银比_FRED.py",
    "AG_抓取白银ETF持仓.py",
]

def run_script(name):
    path = os.path.join(SCRIPT_DIR, name)
    if not os.path.exists(path):
        print(f"[WARN] {name} not found"); return None
    print(f">>> Running {name}...")
    try:
        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"
        r = subprocess.run([sys.executable, path, "--auto"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=60, env=env)
        out = (r.stdout or "").strip()
        if out:
            for line in out.splitlines()[-4:]: print(f"    {line}")
        if r.returncode == 0:
            print(f"[OK] {name} done"); return True
        else:
            print(f"[WARN] {name} exit:{r.returncode}"); return False
    except Exception as e:
        print(f"[ERR] {name} exception: {e}"); return False

def main():
    print("=" * 50)
    print(f"AG Data Collection @ {datetime.now()}")
    print(f"Scripts: {len(SCRIPTS)}")
    print("=" * 50)
    t0 = time.time(); ok, fail = 0, 0
    for s in SCRIPTS:
        r = run_script(s)
        if r: ok += 1
        else: fail += 1
        time.sleep(1)
    print("=" * 50)
    print(f"AG Done  {time.time()-t0:.1f}s  {ok}/{ok+fail}")
    print("=" * 50)

if __name__ == "__main__":
    main()
