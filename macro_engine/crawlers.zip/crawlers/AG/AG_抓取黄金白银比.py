#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AG_抓取黄金白银比.py
因子: AG_MACRO_GOLD_SILVER_RATIO (金银比)
数据源: L1=AKShare spot_golden_benchmark_sge + spot_silver_benchmark_sge → 计算比值
金银比 = 黄金现货价(CNY/g) / 白银现货价(CNY/g)
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value
import akshare as ak
import pandas as pd

FACTOR_CODE = "AG_MACRO_GOLD_SILVER_RATIO"
SYMBOL = "AG"
EMIN = 30.0
EMAX = 100.0

def fetch():
    # L1: 黄金现货（SGE）→ 单位 CNY/g
    print("[L1] spot_golden_benchmark_sge...")
    df_gold = ak.spot_golden_benchmark_sge()
    if df_gold is None or df_gold.empty:
        raise ValueError("spot_golden_benchmark_sge 返回空")
    df_gold = df_gold.sort_values(df_gold.columns[0])
    latest_gold = df_gold.iloc[-1]
    gold_date = pd.to_datetime(latest_gold[df_gold.columns[0]]).date()
    gold_price = float(latest_gold[df_gold.columns[1]])  # 午市价 CNY/g
    print(f"  黄金: {gold_date} 午市价={gold_price} CNY/g")

    # L1: 白银现货（SGE）→ 单位 CNY/kg，需转换为 CNY/g
    print("[L1] spot_silver_benchmark_sge...")
    df_silver = ak.spot_silver_benchmark_sge()
    if df_silver is None or df_silver.empty:
        raise ValueError("spot_silver_benchmark_sge 返回空")
    df_silver = df_silver.sort_values(df_silver.columns[0])
    latest_silver = df_silver.iloc[-1]
    silver_date = pd.to_datetime(latest_silver[df_silver.columns[0]]).date()
    silver_price = float(latest_silver[df_silver.columns[1]]) / 1000.0  # CNY/kg → CNY/g
    print(f"  白银: {silver_date} 午市价={silver_price} CNY/g")

    if silver_price <= 0:
        raise ValueError(f"白银价格异常: {silver_price}")

    obs_date = max(gold_date, silver_date)
    raw_value = round(gold_price / silver_price, 4)
    print(f"[L1] 金银比={raw_value} obs={obs_date}")

    # 合理性校验
    if not (EMIN <= raw_value <= EMAX):
        print(f"[校验失败] 金银比{raw_value}超出范围[{EMIN},{EMAX}]")
        raise ValueError(f"金银比{raw_value}超出合理范围")

    return raw_value, obs_date

def main():
    ensure_table()
    pub_date, obs_date = get_pit_dates()
    print(f"(auto) === {FACTOR_CODE} === pub={pub_date} obs={obs_date}")
    try:
        raw_value, data_obs_date = fetch()
        # 用实际数据日期覆盖 obs_date（周一取上周五）
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, data_obs_date, raw_value,
                   source_confidence=1.0, source="akshare_SGE_金银比")
        print(f"[OK] {FACTOR_CODE}={raw_value} obs={data_obs_date} L1成功")
    except Exception as e:
        print(f"[L1失败] {e}")
        latest = get_latest_value(FACTOR_CODE, SYMBOL)
        if latest is not None:
            save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, latest,
                       source_confidence=0.5, source="db_回补")
            print(f"[OK-L4] {FACTOR_CODE}={latest} L4回补成功")
        else:
            print(f"⚠️ {FACTOR_CODE} 无历史数据，跳过")

if __name__ == "__main__":
    main()
