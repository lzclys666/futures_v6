#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AG_抓取COMEX黄金库存.py — COMEX黄金库存

数据源：
  L1: AKShare futures_comex_inventory() COMEX黄金库存（吨）
  L2: 数据库历史最新值

因子：AG_INV_COMEX_GOLD（吨）
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value

import akshare as ak
from datetime import timedelta

FACTOR_CODE = "AG_INV_COMEX_GOLD"
SYMBOL = "AG"
MIN_VALUE = 500
MAX_VALUE = 1500


def main():
    pub_date, obs_date = get_pit_dates(freq="日频")
    if obs_date is None:
        from datetime import date
        obs_date = date.today()
        for d in range(1, 10):
            check = obs_date - timedelta(days=d)
            if check.weekday() < 5:
                obs_date = check
                break
        pub_date = obs_date

    ensure_table()
    print(f"=== COMEX黄金库存 === obs={obs_date}")

    value = None

    # L1: COMEX黄金库存
    try:
        df = ak.futures_comex_inventory()
        if df is not None and not df.empty:
            latest = df.sort_values('日期').iloc[-1]
            stock = float(latest['COMEX黄金库存量-吨'])
            obs_str = latest['日期'].strftime('%Y-%m-%d')
            if MIN_VALUE <= stock <= MAX_VALUE:
                value = stock
                print(f"[L1] COMEX黄金={stock:.3f}吨 (观测={obs_str})")
            else:
                print(f"[L1] COMEX黄金={stock} 超出范围[{MIN_VALUE}~{MAX_VALUE}]")
    except Exception as e:
        print(f"[L1] COMEX黄金库存失败: {e}")

    # L2: 回退
    if value is None:
        for delta in [1, 2, 3]:
            prev = obs_date - timedelta(days=delta)
            try:
                df = ak.futures_comex_inventory()
                if df is not None and not df.empty:
                    df2 = df[df['日期'].astype(str).str.startswith(prev.strftime('%Y-%m-%d'))]
                    if not df2.empty:
                        stock = float(df2.iloc[-1]['COMEX黄金库存量-吨'])
                        if MIN_VALUE <= stock <= MAX_VALUE:
                            value = stock
                            print(f"[L1] COMEX黄金={stock:.3f}吨 (日期={prev})")
                            break
            except Exception:
                continue

    # L3: DB兜底
    if value is None:
        val = get_latest_value(FACTOR_CODE, SYMBOL)
        if val is not None:
            value = val
            print(f"[L3] DB兜底: {value}")

    if value is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, value, source_confidence=1.0)
        print(f"OK: AG_INV_COMEX_GOLD={value:.3f}")
    else:
        print("FAIL: COMEX黄金库存无数据")
        exit(1)


if __name__ == "__main__":
    main()
