#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AG_抓取净持仓.py
因子: AG_POS_NET (白银净持仓)
数据源: L1=AKShare futures_main_sina(AG0持仓量)
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value
import akshare as ak

FACTOR_CODE = "AG_POS_NET"
SYMBOL = "AG"

def fetch():
    print("[L1] AKShare futures_main_sina AG0...")
    df = ak.futures_main_sina(symbol="AG0")
    if df is None or len(df) == 0:
        return None
    col_map = {str(c).strip(): c for c in df.columns}
    if "持仓量" in col_map:
        val = float(df.iloc[-1][col_map["持仓量"]])
        print(f"[L1] AG持仓量={val}")
        return val
    return None

def main():
    import argparse
    ensure_table()
    pub_date, obs_date = get_pit_dates()
    print(f"(auto) === {FACTOR_CODE} === obs={obs_date}")
    val = fetch()
    if val is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, val, source_confidence=1.0, source="akshare_futures_main_sina")
        print(f"✅ {FACTOR_CODE}={val} 写入成功")
    else:
        v = get_latest_value(FACTOR_CODE, SYMBOL)
        if v is not None:
            save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, v, source_confidence=0.5, source="db_回补")
            print(f"✅ {FACTOR_CODE}={v} L4回补成功")

if __name__ == "__main__":
    main()
