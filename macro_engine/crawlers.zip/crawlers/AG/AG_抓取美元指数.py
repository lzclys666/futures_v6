#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AG_抓取美元指数.py
因子: AG_MACRO_DXY (美元指数DXY)
数据源: L1=FRED API (DXY) → L4回补
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value

FACTOR_CODE = "AG_MACRO_DXY"
SYMBOL = "AG"

def fetch():
    try:
        import requests
        print("[L1] FRED DXY...")
        url = "https://api.stlouisfed.org/fred/series/observations?series_id=DXY&api_key=YOUR_KEY&file_type=json"
        resp = requests.get(url, timeout=10)
        if resp.status_code == 200:
            return None  # 需要FRED API Key
    except:
        pass
    print("[L4] DB历史回补...")
    return get_latest_value(FACTOR_CODE, SYMBOL)

def main():
    import argparse
    ensure_table()
    pub_date, obs_date = get_pit_dates()
    print(f"(auto) === {FACTOR_CODE} === obs={obs_date}")
    val = fetch()
    if val is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, val, source_confidence=0.8, source="fred_api")
        print(f"✅ {FACTOR_CODE}={val} 写入成功")
    else:
        print(f"⚠️  {FACTOR_CODE} 无FRED API Key，请手动录入")

if __name__ == "__main__":
    main()
