#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AG_抓取黄金白银比_FRED.py
因子: AG_MACRO_GOLD_SILVER_RATIO (金银比)
数据源: L1=FRED(AU/USD和AG/USD) → L4回补
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value

FACTOR_CODE = "AG_MACRO_GOLD_SILVER_RATIO"
SYMBOL = "AG"

def fetch():
    print("[L4] DB历史回补（无免费金/银美元报价API）...")
    return get_latest_value(FACTOR_CODE, SYMBOL)

def main():
    import argparse
    ensure_table()
    pub_date, obs_date = get_pit_dates()
    print(f"(auto) === {FACTOR_CODE} === obs={obs_date}")
    val = fetch()
    if val is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, val, source_confidence=0.5, source="db_回补")
        print(f"✅ {FACTOR_CODE}={val} L4回补成功")

if __name__ == "__main__":
    main()
