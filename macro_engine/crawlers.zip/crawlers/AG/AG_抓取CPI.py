#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AG_抓取CPI.py
因子: AG_MACRO_US_CPI_YOY (美国CPI同比)
数据源: L1=AKShare macro_usa_cpi_yoy() → L4回补
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value
import akshare as ak

FACTOR_CODE = "AG_MACRO_US_CPI_YOY"
SYMBOL = "AG"

def fetch():
    print("[L1] AKShare macro_usa_cpi_yoy...")
    try:
        df = ak.macro_usa_cpi_yoy()
        if df is not None and len(df) > 0:
            val = float(df.iloc[-1].iloc[-1])
            print(f"[L1] US CPI={val}%")
            return val
    except Exception as e:
        print(f"[L1] 失败: {e}")
    print("[L4] DB回补...")
    return get_latest_value(FACTOR_CODE, SYMBOL)

def main():
    import argparse
    ensure_table()
    pub_date, obs_date = get_pit_dates()
    print(f"(auto) === {FACTOR_CODE} === obs={obs_date}")
    val = fetch()
    if val is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, val, source_confidence=1.0, source="akshare_macro")
        print(f"✅ {FACTOR_CODE}={val} 写入成功")

if __name__ == "__main__":
    main()
