#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AG_抓取CFTC白银持仓.py
因子: AG_POS_CFTC_NET (CFTC白银非商业净持仓)
数据源: L1=AKShare macro_usa_cftc_nc_holding(NC净持仓), macro_usa_cftc_c_holding(商业持仓)
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value
import akshare as ak

FACTOR_CODE = "AG_POS_CFTC_NET"
SYMBOL = "AG"

def fetch():
    print("[L1] AKShare macro_usa_cftc_nc_holding...")
    df = ak.macro_usa_cftc_nc_holding()
    if df is not None and len(df) > 0:
        # 28列=1日期+7商品×4(多/多变化/空/空变化)，最后一组是白银
        # 白银净持仓=多头(列25)-空头(列27)，列从0开始
        cols = df.columns.tolist()
        row = df.iloc[-1]
        long_col = len(cols) - 3   # 倒数第3列：白银多头持仓
        short_col = len(cols) - 1  # 最后一列：白银空头变化（注：净持仓=多-空变化?）
        # 实际上列25=白银多头持仓，列26=白银多头变化，列27=白银空头变化
        # 净持仓变化=列3（每周变化列）
        val = float(row.iloc[long_col])  # 白银多头持仓（手）
        print(f"[L1] 白银CFTC多头持仓={val}手 (列{long_col})")
        return val
    return None

def main():
    import argparse
    ensure_table()
    pub_date, obs_date = get_pit_dates()
    print(f"(auto) === {FACTOR_CODE} === obs={obs_date}")
    val = fetch()
    if val is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, val, source_confidence=1.0, source="akshare_cftc")
        print(f"✅ {FACTOR_CODE}={val} 写入成功")
    else:
        v = get_latest_value(FACTOR_CODE, SYMBOL)
        if v is not None:
            save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, v, source_confidence=0.5, source="db_回补")
            print(f"✅ {FACTOR_CODE}={v} L4回补成功")

if __name__ == "__main__":
    main()
