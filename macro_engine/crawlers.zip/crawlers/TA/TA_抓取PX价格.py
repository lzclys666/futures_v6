#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TA_抓取PX价格.py
因子: TA_CST_PX = PX CFR中国价格（美元/吨）

付费来源: 隆众资讯(年费) | 普氏(付费) | 卓创资讯(年费)
当前状态: [WARN]️ 永久跳过 -- 无免费数据源，不写占位符，不做L4回补
订阅隆众资讯后从年费账号导出数据，手动录入本因子
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from common.db_utils import ensure_table, get_pit_dates

SYMBOL = "TA"
FACTOR_CODE = "TA_CST_PX"


def main():
    ensure_table()
    pub_date, obs_date = get_pit_dates()
    print(f"(auto) === {FACTOR_CODE} === obs={obs_date}")

    # L1: 无免费数据源
    print("  [跳过] PX CFR中国无免费数据源（付费:隆众资讯/普氏/卓创资讯）")
    print("  [跳过] 订阅付费后从年费账号导出，手动录入本因子")
    print("  [跳过] 不写占位符，不做L4回补（付费数据无意义回补）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
