#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TA_抓取聚酯开工率.py
因子: TA_DEM_POLYESTER_OP = 聚酯开工率（%）

当前状态: [WARN]️ 永久跳过 -- 无免费API（CCF/隆众资讯付费）
订阅隆众资讯后从年费账号导出数据，手动录入本因子
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from common.db_utils import ensure_table, get_pit_dates

FACTOR_CODE = "TA_DEM_POLYESTER_OP"
SYMBOL = "TA"


def main():
    ensure_table()
    pub_date, obs_date = get_pit_dates()
    print(f"(auto) === {FACTOR_CODE} === obs={obs_date}")
    print("  [跳过] 聚酯开工率无免费API（付费:隆众资讯/CCF资讯）")
    print("  [跳过] 不写占位符，订阅付费后手动录入")
    return 0


if __name__ == "__main__":
    sys.exit(main())
