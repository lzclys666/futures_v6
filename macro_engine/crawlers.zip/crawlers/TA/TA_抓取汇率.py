#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 数据源说明:
#   L1 免费: 新浪/腾讯实时汇率 (USDCNY)
#   L2 免费: AKShare futures_spot_price(有美元数据列)
#   L3 付费: Wind/Bloomberg (终端)
#   L4 兜底: 历史回补
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value
import akshare as ak
import requests

SYMBOL = "TA"

def fetch_usd_cny_sina():
    """新浪USDCNY实时汇率"""
    try:
        r = requests.get(
            'https://hq.sinajs.cn/list=USDCNY,USDCNH',
            headers={'User-Agent': 'Mozilla/5.0', 'Referer': 'https://finance.sina.com.cn'},
            timeout=10
        )
        r.encoding = 'utf-8'
        for line in r.text.strip().split('\n'):
            if 'USDCNY' in line and 'pv_none' not in line:
                parts = line.split('"')[1].split(',')
                if len(parts) > 1:
                    return float(parts[1])
    except Exception as e:
        print(f"  [L1] 新浪汇率失败: {e}")
    return None

def fetch_usd_cny_qq():
    """腾讯USDCNY实时汇率"""
    try:
        r = requests.get(
            'https://qt.gtimg.cn/q=USDCNY,USDCNH',
            headers={'User-Agent': 'Mozilla/5.0'},
            timeout=10
        )
        r.encoding = 'gbk'
        for line in r.text.strip().split('\n'):
            if 'USDCNY' in line and 'pv_none' not in line:
                parts = line.split('"')[1].split(',')
                if len(parts) > 1:
                    return float(parts[1])
    except Exception as e:
        print(f"  [L2] 腾讯汇率失败: {e}")
    return None

def main():
    ensure_table()
    pub_date, obs_date = get_pit_dates()
    print(f"(auto) === TA_USDCNY汇率 === obs={obs_date}")

    # L1: 新浪
    rate = fetch_usd_cny_sina()
    src = "新浪财经"

    # L2: 腾讯
    if rate is None:
        rate = fetch_usd_cny_qq()
        src = "腾讯财经"

    if rate:
        print(f"  {src} USDCNY: {rate}")
        save_to_db("TA_CST_USDCNY", SYMBOL, pub_date, obs_date, rate, src, 1.0)
        print(f">>> TA_CST_USDCNY={rate} 写入成功")
    else:
        print("  [L1/L2] 无免费汇率数据")
        val = get_latest_value("TA_CST_USDCNY", SYMBOL)
        if val is not None:
            save_to_db("TA_CST_USDCNY", SYMBOL, pub_date, obs_date, val, source_confidence=0.5, source="db_回补")
            print(f">>> TA_CST_USDCNY={val} L4回补成功")
        else:
            print("FAIL: USDCNY无数据")

if __name__ == "__main__":
    main()
