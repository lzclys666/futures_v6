# -*- coding: utf-8 -*-
"""
扫描所有品种因子脚本的Header合规性
检查项：shebang、coding、docstring结构、因子代码定义
"""
import os, re

ROOT = r'D:\futures_v6\macro_engine\crawlers'
EXCLUDE = {'common', 'logs', '_backup_rename', '_backup_rename2', '_backup_rename3', '_backup_rename4', '_backup_rename5'}

def check_script(path):
    """返回 (合规bool, 问题列表, 当前状态)"""
    issues = []
    state = '未知'
    
    try:
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        lines = content.split('\n')
    except UnicodeDecodeError:
        try:
            with open(path, 'r', encoding='gbk') as f:
                content = f.read()
            lines = content.split('\n')
        except:
            return False, ['无法读取文件(utf-8/gbk)'], '未知'
    
    # 1. shebang
    if not lines[0].startswith('#!/'):
        issues.append('缺shebang')
    
    # 2. coding声明
    has_coding = any('coding' in l or 'utf-8' in l or 'gbk' in l for l in lines[:3])
    if not has_coding:
        issues.append('缺coding声明')
    
    # 3. 检查docstring
    docstring_lines = []
    in_docstring = False
    docstring_start = -1
    for i, l in enumerate(lines):
        if l.strip().startswith('"""') or l.strip().startswith("'''"):
            if not in_docstring:
                in_docstring = True
                docstring_start = i
            else:
                # docstring ends
                docstring_lines = lines[docstring_start:i+1]
                break
        elif in_docstring:
            docstring_lines.append(l)
    
    # 4. 解析docstring内容
    full_doc = '\n'.join(docstring_lines)
    
    # 检查因子代码
    has_factor_code = re.search(r'因子[:：]\s*\w+\s*=', full_doc) is not None
    if not has_factor_code:
        issues.append('docstring缺"因子: FACTOR_CODE ="')
    
    # 检查状态标签
    state_match = re.search(r'当前状态[:：]\s*\[?(✅|⚠️|⛔|OK|正常|待修复|永久跳过|跳过)', full_doc)
    if state_match:
        state = state_match.group(1)
    elif '当前状态' in full_doc:
        issues.append('docstring缺状态标签')
        state = '⚠️待修复'
    else:
        issues.append('docstring缺"当前状态:"')
        state = '⚠️待修复'
    
    # 检查公式行
    if '公式:' not in full_doc and '公式:' not in content:
        issues.append('docstring缺"公式:"')
    
    return len(issues) == 0, issues, state

def main():
    results = []
    total = 0
    compliant = 0
    
    for variety in sorted(os.listdir(ROOT)):
        vpath = os.path.join(ROOT, variety)
        if not os.path.isdir(vpath) or variety in EXCLUDE:
            continue
        
        for fname in sorted(os.listdir(vpath)):
            if not fname.endswith('.py'):
                continue
            # 跳过run_all.py（汇总脚本，不需要因子Header）
            if fname.endswith('_run_all.py'):
                continue
            # 跳过test_patch等临时文件
            if fname.startswith('_'):
                continue
            
            fpath = os.path.join(vpath, fname)
            total += 1
            ok, issues, state = check_script(fpath)
            if ok:
                compliant += 1
            else:
                results.append((variety, fname, state, issues))
    
    print(f"=== Header合规性审计 ===")
    print(f"总脚本数: {total}")
    print(f"合规: {compliant}/{total} ({100*compliant/total:.1f}%)")
    print(f"不合规: {len(results)}/{total}")
    print()
    
    # 按品种分组显示
    by_variety = {}
    for v, fname, state, issues in sorted(results):
        if v not in by_variety:
            by_variety[v] = []
        by_variety[v].append((fname, state, issues))
    
    for v in sorted(by_variety.keys()):
        scripts = by_variety[v]
        print(f"\n【{v}】{len(scripts)}个不合规:")
        for fname, state, issues in scripts:
            print(f"  {fname}: [{state}] {' | '.join(issues)}")
    
    # 写JSON输出供后续处理
    import json
    out = {'total': total, 'compliant': compliant, 'non_compliant': len(results),
           'details': [{'variety': v, 'fname': f, 'state': s, 'issues': i} for v, f, s, i in results]}
    with open(os.path.join(ROOT, '_header_audit_result.json'), 'w', encoding='utf-8') as outf:
        json.dump(out, outf, ensure_ascii=False, indent=2)
    print(f"\n详细结果已写入 _header_audit_result.json")

if __name__ == '__main__':
    main()
