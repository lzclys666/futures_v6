#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AU_抓取Fed点阵图.py
因子: AU_FED_DOT = 美联储点阵图中位数（联邦基金利率预期中值，%）
# 付费来源: federalreserve.gov (FOMC projections page, 2024年改版后404)

数据源:
  L1: 无（federalreserve.gov 2024年改版，fomcprojtable.htm等所有历史投影表返回404）
  L2: 尝试FRED API（需API key）
  L4: 历史回补（无免费源时取DB最新值）
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value

FACTOR_CODE = "AU_FED_DOT"
SYMBOL = "AU"


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--auto', action='store_true')
    args = parser.parse_args()

    ensure_table()
    pub_date, obs_date = get_pit_dates()

    # L4: 历史回补
    latest = get_latest_value(FACTOR_CODE, SYMBOL)
    if latest is not None:
        print(f"[L4] AU_FED_DOT={latest}% (L4 fallback from DB)")
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, latest,
                   source_confidence=0.5, source="L4_historical_fallback")
        print(f"[OK] {FACTOR_CODE}={latest} 写入成功")
    else:
        print(f"[SKIP] {FACTOR_CODE} 无数据且DB无历史值（付费订阅: federalreserve.gov FOMC projections）")


if __name__ == "__main__":
    main()
