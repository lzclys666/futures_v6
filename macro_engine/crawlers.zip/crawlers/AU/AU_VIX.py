# -*- coding: utf-8 -*-
"""
AU_VIX.py - VIX恐慌指数
因子分析师交付文档: AU_VIX (梯队: 第二梯队)
数据源: FRED (联邦储备银行圣路易斯) - series: VIXCLS
AKShare无此接口，用FRED官方CSV替代 ✅
"""
import sys, os
this_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(this_dir, '..', 'common'))
from db_utils import save_to_db
from datetime import date, datetime
import requests
import functools
print_enc = functools.partial(print, flush=True)

FCODE = "AU_VIX"
SYM = "AU"
EMIN = 5.0
EMAX = 80.0

def fetch():
    """L1: FRED VIX series (VIXCLS)"""
    try:
        url = 'https://fred.stlouisfed.org/graph/fredgraph.csv?id=VIXCLS'
        r = requests.get(url, timeout=15)
        if r.status_code != 200:
            print_enc("[L1] FRED VIX status=" + str(r.status_code))
            return None, None
        lines = r.text.strip().split('\n')
        if len(lines) < 2:
            print_enc("[L1] FRED VIX: empty data")
            return None, None
        last_line = lines[-1]
        parts = last_line.split(',')
        obs_date_str = parts[0]
        raw_value = float(parts[1])
        obs_date = datetime.strptime(obs_date_str, '%Y-%m-%d').date()
        print_enc("[L1] VIX=" + str(raw_value) + " obs=" + str(obs_date) + " via FRED VIXCLS")
        return raw_value, obs_date
    except Exception as e:
        print_enc("[L1] VIX ERROR: " + str(e)[:80])
    return None, None

def main():
    raw_value, obs_date = fetch()
    if raw_value is None:
        print_enc("[SKIP] " + FCODE + ": No data")
        return
    if not (EMIN <= raw_value <= EMAX):
        print_enc("[WARN] " + FCODE + "=" + str(raw_value) + " out of bounds [" + str(EMIN) + "," + str(EMAX) + "]")
        return
    save_to_db(FCODE, SYM, date.today(), obs_date, raw_value, source_confidence=1.0,
               source='FRED VIXCLS (CBOE VIX)')
    print_enc("[OK] " + FCODE + "=" + str(raw_value) + " obs=" + str(obs_date))

if __name__ == "__main__":
    main()
