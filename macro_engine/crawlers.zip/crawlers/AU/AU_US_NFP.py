# -*- coding: utf-8 -*-
"""
AU_US_NFP.py - 美国新增非农就业人数（月度）
因子分析师交付文档: AU_US_NFP (梯队: 第二梯队)
数据源: AKShare macro_usa_non_farm
注意: AKShare macro_usa_non_farm 数据可能有1-3个月滞后
"""
import sys, os
this_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(this_dir, '..', 'common'))
from db_utils import save_to_db
from datetime import date, datetime
import warnings
warnings.filterwarnings('ignore')
import functools
print_enc = functools.partial(print, flush=True)

FCODE = "AU_US_NFP"
SYM = "AU"
EMIN = -5000.0   # 大衰退时期非农最低约-800万（2020年4月）
EMAX = 5000.0    # 正常范围约-500到+500万

def fetch():
    try:
        import akshare as ak
        df = ak.macro_usa_non_farm()
        if df is None or df.empty:
            print_enc("[L1] NFP: empty DataFrame")
            return None, None
        # Filter rows with non-null '今值' (actual value)
        df = df[df['今值'].notna()]
        if df.empty:
            print_enc("[L1] NFP: all values are NaN")
            return None, None
        df = df.sort_values('日期', ascending=False)
        latest = df.iloc[0]
        raw_value = float(latest['今值'])
        obs_date_str = str(latest['日期'])[:10]
        obs_date = datetime.strptime(obs_date_str, '%Y-%m-%d').date()
        print_enc("[L1] NFP=" + str(raw_value) + " (10k) obs=" + str(obs_date) + " via AKShare macro_usa_non_farm")
        return raw_value, obs_date
    except Exception as e:
        print_enc("[L1] NFP ERROR: " + str(e)[:80])
    return None, None

def main():
    raw_value, obs_date = fetch()
    if raw_value is None:
        print_enc("[SKIP] " + FCODE + ": No data")
        return
    # Unit: AKShare returns in 万 (10k), e.g. 14.7 = 14.7万 = 147,000 jobs
    if not (EMIN <= raw_value <= EMAX):
        print_enc("[WARN] " + FCODE + "=" + str(raw_value) + " out of bounds [" + str(EMIN) + "," + str(EMAX) + "]")
        return
    save_to_db(FCODE, SYM, date.today(), obs_date, raw_value, source_confidence=0.9,
               source='BLS via AKShare macro_usa_non_farm')
    print_enc("[OK] " + FCODE + "=" + str(raw_value) + " (10k) obs=" + str(obs_date))

if __name__ == "__main__":
    main()
