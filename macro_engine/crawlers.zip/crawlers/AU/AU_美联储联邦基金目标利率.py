# AU_FED_RATE: 美联储联邦基金目标利率
# 第一梯队因子③：美联储联邦基金利率
# L1: macro_bank_usa_interest_rate(akshare) -> Fed利率决策
# 注意: 数据可能滞后，取最新非空值
# -*- coding: utf-8 -*-
import sys, os
this_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(this_dir, '..', 'common'))
from db_utils import save_to_db, get_latest_value
import akshare as ak
from datetime import date
import pandas as pd

FCODE = "AU_FED_RATE"
SYM = "AU"
EMIN = 0.0
EMAX = 10.0

def fetch():
    df = ak.macro_bank_usa_interest_rate()
    if df.empty:
        raise ValueError("macro_bank_usa_interest_rate empty")
    # 列: ['指标', '日期', '数值', '预测值', '前值']
    col_date = df.columns[1]   # 日期
    col_val = df.columns[2]    # 数值
    df = df.dropna(subset=[col_val, col_date])
    df = df.sort_values(col_date)
    latest = df.iloc[-1]
    raw_value = float(latest[col_val])
    obs_date = pd.to_datetime(latest[col_date]).date()
    return raw_value, obs_date

def main():
    try:
        raw_value, obs_date = fetch()
    except Exception as e:
        print("[L1] " + FCODE + ": " + str(e))
        latest = get_latest_value(FCODE, SYM)
        if latest is not None:
            print("[L4] " + FCODE + "=" + str(latest))
        else:
            print("[SKIP] " + FCODE)
        return
    if not (EMIN <= raw_value <= EMAX):
        print("[WARN] " + FCODE + "=" + str(raw_value) + " [" + str(EMIN) + "," + str(EMAX) + "]")
        return
    save_to_db(FCODE, SYM, date.today(), obs_date, raw_value, source_confidence=1.0)
    print("[OK] " + FCODE + "=" + str(raw_value) + " obs=" + str(obs_date))

if __name__ == "__main__":
    main()
