# -*- coding: utf-8 -*-
"""
AU_COMEX_AU.py - COMEX黄金期货价格（美元/盎司）
因子分析师交付文档: AU_COMEX_AU (梯队: 第二梯队)
数据源: AKShare futures_foreign_hist(symbol='GC')
注意: 2026年4月黄金价格约3300-3400美元/盎司（历史新高）
"""
import sys, os
this_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(this_dir, '..', 'common'))
from db_utils import save_to_db
from datetime import date, datetime
import warnings
warnings.filterwarnings('ignore')
import functools
print_enc = functools.partial(print, flush=True)

FCODE = "AU_COMEX_AU"
SYM = "AU"
EMIN = 1000.0   # 历史下限（2020年前约1000-2000）
EMAX = 4000.0   # 2026年历史上限约3400

def fetch():
    try:
        import akshare as ak
        df = ak.futures_foreign_hist(symbol='GC')
        if df is None or df.empty:
            print_enc("[L1] COMEX AU: empty DataFrame")
            return None, None
        latest = df.sort_values('date', ascending=False).iloc[0]
        raw_value = float(latest['close'])
        obs_date_str = str(latest['date'])[:10]
        obs_date = datetime.strptime(obs_date_str, '%Y-%m-%d').date()
        print_enc("[L1] COMEX_AU=" + str(raw_value) + " obs=" + str(obs_date) + " via AKShare futures_foreign_hist(GC)")
        return raw_value, obs_date
    except Exception as e:
        print_enc("[L1] COMEX AU ERROR: " + str(e)[:80])
    return None, None

def main():
    raw_value, obs_date = fetch()
    if raw_value is None:
        print_enc("[SKIP] " + FCODE + ": No data")
        return
    if not (EMIN <= raw_value <= EMAX):
        print_enc("[WARN] " + FCODE + "=" + str(raw_value) + " out of bounds [" + str(EMIN) + "," + str(EMAX) + "]")
    save_to_db(FCODE, SYM, date.today(), obs_date, raw_value, source_confidence=1.0,
               source='COMEX Gold (GC) via AKShare futures_foreign_hist')
    print_enc("[OK] " + FCODE + "=" + str(raw_value) + " obs=" + str(obs_date))

if __name__ == "__main__":
    main()
