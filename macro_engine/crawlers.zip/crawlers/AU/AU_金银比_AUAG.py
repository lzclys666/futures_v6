# AU_SPD_AUAG: 金银比 = SGE黄金现货价 / SGE白银现货价
# 第一梯队因子⑩（新增）：金银比跨品种对冲比率
# L1: spot_golden_benchmark_sge + spot_silver_benchmark_sge(akshare)
# 金银比↑→黄金相对偏强（多金空银）；金银比↓→白银相对偏强（多银空金）
# -*- coding: utf-8 -*-
import sys, os
this_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(this_dir, '..', 'common'))
from db_utils import save_to_db, get_latest_value
import akshare as ak
from datetime import date
import pandas as pd

FCODE = "AU_SPD_AUAG"
SYM = "AU"
EMIN = 30.0
EMAX = 100.0

def fetch():
    # 黄金现货（SGE）：['交易时间', '午市价', '早市价']
    df_gold = ak.spot_golden_benchmark_sge()
    if df_gold.empty:
        raise ValueError("spot_golden_benchmark_sge empty")
    df_gold = df_gold.sort_values(df_gold.columns[0])
    latest_gold = df_gold.iloc[-1]
    gold_date = pd.to_datetime(latest_gold[df_gold.columns[0]]).date()
    # 黄金现货（SGE）：单位 CNY/g
    gold_price = float(latest_gold[df_gold.columns[1]])  # 午市价，单位 CNY/g

    # 白银现货（SGE）：单位 CNY/kg，需转换为 CNY/g
    df_silver = ak.spot_silver_benchmark_sge()
    if df_silver.empty:
        raise ValueError("spot_silver_benchmark_sge empty")
    df_silver = df_silver.sort_values(df_silver.columns[0])
    latest_silver = df_silver.iloc[-1]
    silver_date = pd.to_datetime(latest_silver[df_silver.columns[0]]).date()
    # SGE白银基准价单位是 CNY/kg，转为 CNY/g
    silver_price = float(latest_silver[df_silver.columns[1]]) / 1000.0  # 午市价，单位 CNY/g

    if silver_price <= 0:
        raise ValueError("silver price <= 0: " + str(silver_price))

    obs_date = max(gold_date, silver_date)
    raw_value = round(gold_price / silver_price, 4)
    return raw_value, obs_date

def main():
    try:
        raw_value, obs_date = fetch()
    except Exception as e:
        print("[L1] " + FCODE + ": " + str(e))
        latest = get_latest_value(FCODE, SYM)
        if latest is not None:
            print("[L4] " + FCODE + "=" + str(latest))
        else:
            print("[SKIP] " + FCODE)
        return
    if not (EMIN <= raw_value <= EMAX):
        print("[WARN] " + FCODE + "=" + str(raw_value) + " [" + str(EMIN) + "," + str(EMAX) + "]")
        return
    save_to_db(FCODE, SYM, date.today(), obs_date, raw_value, source_confidence=1.0)
    print("[OK] " + FCODE + "=" + str(raw_value) + " obs=" + str(obs_date))

if __name__ == "__main__":
    main()
