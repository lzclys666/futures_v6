# -*- coding: utf-8 -*-
"""
AU_US_CPI.py - 美国CPI同比增速（%）
因子分析师交付文档: AU_US_CPI (梯队: 第二梯队)
数据源: AKShare macro_usa_cpi_yoy
注意: AKShare macro_usa_cpi_yoy 数据可能有1-2个月滞后
"""
import sys, os
this_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(this_dir, '..', 'common'))
from db_utils import save_to_db
from datetime import date, datetime
import warnings
warnings.filterwarnings('ignore')
import functools
print_enc = functools.partial(print, flush=True)

FCODE = "AU_US_CPI"
SYM = "AU"
EMIN = -2.0    # 历史最低约-2%（大萧条/疫情）
EMAX = 15.0    # 历史最高约14.8%（1979石油危机）

def fetch():
    try:
        import akshare as ak
        df = ak.macro_usa_cpi_yoy()
        if df is None or df.empty:
            print_enc("[L1] CPI: empty DataFrame")
            return None, None
        df = df[df['现值'].notna()]
        if df.empty:
            print_enc("[L1] CPI: all values are NaN")
            return None, None
        df = df.sort_values('发布日期', ascending=False)
        latest = df.iloc[0]
        raw_value = float(latest['现值'])
        obs_date_str = str(latest['发布日期'])[:10]
        obs_date = datetime.strptime(obs_date_str, '%Y-%m-%d').date()
        print_enc("[L1] CPI=" + str(raw_value) + "% obs=" + str(obs_date) + " via AKShare macro_usa_cpi_yoy")
        return raw_value, obs_date
    except Exception as e:
        print_enc("[L1] CPI ERROR: " + str(e)[:80])
    return None, None

def main():
    raw_value, obs_date = fetch()
    if raw_value is None:
        print_enc("[SKIP] " + FCODE + ": No data")
        return
    if not (EMIN <= raw_value <= EMAX):
        print_enc("[WARN] " + FCODE + "=" + str(raw_value) + " out of bounds [" + str(EMIN) + "," + str(EMAX) + "]")
        return
    save_to_db(FCODE, SYM, date.today(), obs_date, raw_value, source_confidence=0.9,
               source='BLS via AKShare macro_usa_cpi_yoy')
    print_enc("[OK] " + FCODE + "=" + str(raw_value) + "% obs=" + str(obs_date))

if __name__ == "__main__":
    main()
