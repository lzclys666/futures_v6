# AU_SPD_BASIS: 黄金期现基差 = SGE现货 - SHFE期货
# -*- coding: utf-8 -*-
import sys, os
this_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(this_dir, '..', 'common'))
from db_utils import save_to_db, get_latest_value
import akshare as ak
from datetime import date
import pandas as pd

FCODE = "AU_SPD_BASIS"
SYM = "AU"
EMIN = -100
EMAX = 100

def fetch():
    # AU0: ['日期', '开盘价', '最高价', '最低价', '收盘价', '成交量', '持仓量', '动态结算价']
    # Index:      [0]      [1]       [2]       [3]        [4]       [5]      [6]       [7]
    df1 = ak.futures_main_sina(symbol="AU0")
    if df1.empty:
        raise ValueError("AU0 no data")
    fut = df1.sort_values(df1.columns[0]).iloc[-1]
    fut_price = float(fut.iloc[4])  # 收盘价
    fut_date = pd.to_datetime(fut.iloc[0]).date()

    # SGE: ['交易时间', '晚盘价', '早盘价']
    # Index:       [0]          [1]        [2]
    df2 = ak.spot_golden_benchmark_sge()
    if df2.empty:
        raise ValueError("SGE no data")
    spot = df2.sort_values(df2.columns[0]).iloc[-1]
    spot_price = float(spot.iloc[1])  # 晚盘价
    spot_date = pd.to_datetime(spot.iloc[0]).date()

    obs_date = max(fut_date, spot_date)
    raw_value = round(spot_price - fut_price, 2)
    return raw_value, obs_date

def main():
    try:
        raw_value, obs_date = fetch()
    except Exception as e:
        print("[L1] " + FCODE + ": " + str(e))
        latest = get_latest_value(FCODE, SYM)
        if latest is not None:
            print("[L4] " + FCODE + "=" + str(latest))
        else:
            print("[SKIP] " + FCODE)
        return
    if not (EMIN <= raw_value <= EMAX):
        print("[WARN] " + FCODE + "=" + str(raw_value) + " [" + str(EMIN) + "," + str(EMAX) + "]")
        return
    save_to_db(FCODE, SYM, date.today(), obs_date, raw_value, source_confidence=1.0)
    print("[OK] " + FCODE + "=" + str(raw_value) + " obs=" + str(obs_date))

if __name__ == "__main__":
    main()
