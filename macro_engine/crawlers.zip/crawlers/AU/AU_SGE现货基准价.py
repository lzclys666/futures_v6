# AU_SPOT_SGE: SGE金条基准价
# -*- coding: utf-8 -*-
import sys, os
this_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(this_dir, '..', 'common'))
from db_utils import save_to_db, get_latest_value
import akshare as ak
from datetime import date, timedelta
import pandas as pd

FCODE = "AU_SPOT_SGE"
SYM = "AU"
EMIN = 500
EMAX = 1500

def fetch():
    df = ak.spot_golden_benchmark_sge()
    if df.empty:
        raise ValueError("SGE no data")
    latest = df.sort_values(df.columns[0]).iloc[-1]
    # '交易时间', '晚盘价', '早盘价'
    date_col = df.columns[0]  # 交易时间
    price_col = df.columns[1]  # 晚盘价
    raw_value = float(latest[price_col])
    obs_date = pd.to_datetime(latest[date_col]).date()
    return raw_value, obs_date

def main():
    try:
        raw_value, obs_date = fetch()
    except Exception as e:
        print("[L1] " + FCODE + ": " + str(e))
        latest = get_latest_value(FCODE, SYM)
        if latest is not None:
            print("[L4] " + FCODE + "=" + str(latest))
        else:
            print("[SKIP] " + FCODE)
        return
    if not (EMIN <= raw_value <= EMAX):
        print("[WARN] " + FCODE + "=" + str(raw_value) + " [" + str(EMIN) + "," + str(EMAX) + "]")
        return
    save_to_db(FCODE, SYM, date.today(), obs_date, raw_value, source_confidence=1.0)
    print("[OK] " + FCODE + "=" + str(raw_value) + " obs=" + str(obs_date))

if __name__ == "__main__":
    main()
