# AU_GOLD_RESERVE_CB: 央行黄金储备
# -*- coding: utf-8 -*-
import sys, os
this_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(this_dir, '..', 'common'))
from db_utils import save_to_db, get_latest_value
import akshare as ak
from datetime import date
import pandas as pd

FCODE = "AU_GOLD_RESERVE_CB"
SYM = "AU"
EMIN = 2000
EMAX = 6000

def parse_month(s):
    # '2026年03月份' -> date(2026, 3, 1)
    import re
    m = re.match(r'(\d{4})年(\d{2})月份', str(s))
    if m:
        return date(int(m.group(1)), int(m.group(2)), 1)
    return None

def fetch():
    df = ak.macro_china_fx_gold()
    if df.empty:
        raise ValueError("CB gold no data")
    # '月份' col, '黄金储备-数值' col
    month_col = df.columns[0]  # 月份
    val_col = '黄金储备-数值'
    # Parse month
    df['_date'] = df[month_col].apply(parse_month)
    df = df.dropna(subset=['_date'])
    df = df.sort_values('_date')
    latest = df.iloc[-1]
    raw_value = float(latest[val_col])
    obs_date = latest['_date']
    return raw_value, obs_date

def main():
    try:
        raw_value, obs_date = fetch()
    except Exception as e:
        print("[L1] " + FCODE + ": " + str(e))
        latest = get_latest_value(FCODE, SYM)
        if latest is not None:
            print("[L4] " + FCODE + "=" + str(latest))
        else:
            print("[SKIP] " + FCODE)
        return
    if not (EMIN <= raw_value <= EMAX):
        print("[WARN] " + FCODE + "=" + str(raw_value) + " [" + str(EMIN) + "," + str(EMAX) + "]")
        return
    save_to_db(FCODE, SYM, date.today(), obs_date, raw_value, source_confidence=1.0)
    print("[OK] " + FCODE + "=" + str(raw_value) + " obs=" + str(obs_date))

if __name__ == "__main__":
    main()
