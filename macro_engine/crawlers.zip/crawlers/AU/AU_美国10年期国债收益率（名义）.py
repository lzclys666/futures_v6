# AU_US_10Y_YIELD: 美国10年期国债收益率
# 第一梯队因子①：TIPS实际收益率代理（使用名义收益率，因AKShare无TIPS专属函数）
# L1: bond_zh_us_rate(akshare) -> 美国10年期国债收益率名义值
# L4: 历史最新值回补
# -*- coding: utf-8 -*-
import sys, os
this_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(this_dir, '..', 'common'))
from db_utils import save_to_db, get_latest_value
import akshare as ak
from datetime import date
import pandas as pd

FCODE = "AU_US_10Y_YIELD"
SYM = "AU"
EMIN = 0.0
EMAX = 10.0

def fetch():
    df = ak.bond_zh_us_rate()
    if df.empty:
        raise ValueError("bond_zh_us_rate empty")
    # 列: ['日期', '中国中债国债2年', '中国中债国债5年', '美国国债收益率10年', ...]
    col_date = df.columns[0]   # 日期
    col_10y = '美国国债收益率10年'
    if col_10y not in df.columns:
        raise ValueError("col not found: " + col_10y)
    df = df.dropna(subset=[col_date])
    df = df.sort_values(col_date)
    latest = df.iloc[-1]
    raw_value = float(latest[col_10y])
    obs_date = pd.to_datetime(latest[col_date]).date()
    return raw_value, obs_date

def main():
    try:
        raw_value, obs_date = fetch()
    except Exception as e:
        print("[L1] " + FCODE + ": " + str(e))
        latest = get_latest_value(FCODE, SYM)
        if latest is not None:
            print("[L4] " + FCODE + "=" + str(latest))
        else:
            print("[SKIP] " + FCODE)
        return
    if not (EMIN <= raw_value <= EMAX):
        print("[WARN] " + FCODE + "=" + str(raw_value) + " [" + str(EMIN) + "," + str(EMAX) + "]")
        return
    save_to_db(FCODE, SYM, date.today(), obs_date, raw_value, source_confidence=0.9)
    print("[OK] " + FCODE + "=" + str(raw_value) + " obs=" + str(obs_date))

if __name__ == "__main__":
    main()
