# -*- coding: utf-8 -*-
"""改进的Header合规性审计"""
import os, re, json

def check_script(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
    except:
        try:
            with open(path, 'r', encoding='gbk') as f:
                content = f.read()
        except:
            return '无法读取', []

    lines = content.split('\n')
    issues = []

    # 1. shebang
    if not lines[0].startswith('#!/'):
        issues.append('缺shebang')

    # 2. coding声明
    has_coding = any('coding' in l or 'utf-8' in l for l in lines[:3])
    if not has_coding:
        issues.append('缺coding')

    # 3. 提取docstring内容
    doc = ''
    in_doc = False
    doc_started = False
    for l in lines:
        stripped = l.strip()
        if stripped.startswith('"""') or stripped.startswith("'''"):
            if not in_doc:
                in_doc = True
                doc_started = True
                # 判断是否单行docstring
                if stripped.count('"""') == 2 or stripped.count("'''") == 2:
                    # 单行
                    doc = stripped.strip('"\'')
                    in_doc = False
                    break
                continue
            else:
                break
        if in_doc:
            doc += l + '\n'

    # 检查关键字段
    has_factor = bool(re.search(r'因子[:：]', doc))
    has_status = bool(re.search(r'当前状态[:：]', doc))
    has_formula = bool(re.search(r'公式[:：]', doc))

    if not has_factor:
        issues.append('缺因子')
    if not has_status:
        issues.append('缺状态')
    if not has_formula:
        issues.append('缺公式')

    return ('OK' if not issues else ', '.join(issues)), issues

def main():
    root = r'D:\futures_v6\macro_engine\crawlers'
    results = {'OK': [], 'issues': []}

    for v in sorted(os.listdir(root)):
        vpath = os.path.join(root, v)
        if not os.path.isdir(vpath) or v in {'common', 'logs', '_backup_rename', '_backup_rename2', '_backup_rename3', '_backup_rename4', '_backup_rename5'}: 
            continue
        for fname in sorted(os.listdir(vpath)):
            if not fname.endswith('.py') or fname.endswith('_run_all.py') or fname.startswith('_'):
                continue
            fpath = os.path.join(vpath, fname)
            status, issues = check_script(fpath)
            if status == 'OK':
                results['OK'].append((v, fname))
            else:
                results['issues'].append((v, fname, status))

    total = len(results['OK']) + len(results['issues'])
    print(f'=== Header合规性审计(改进版) ===')
    print(f'总脚本: {total}')
    print(f'合规: {len(results["OK"])}/{total} ({100*len(results["OK"])/total:.1f}%)')
    print(f'不合规: {len(results["issues"])}/{total}')
    print()
    
    # 按品种统计
    by_v = {}
    for v, fname, iss in results['issues']:
        if v not in by_v:
            by_v[v] = 0
        by_v[v] += 1
    
    print('按品种不合规数量:')
    for v in sorted(by_v.keys()):
        print(f'  {v}: {by_v[v]}')
    
    # 写JSON
    with open(os.path.join(root, '_header_audit2.json'), 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f'\n详细结果已写入 _header_audit2.json')

if __name__ == '__main__':
    main()
