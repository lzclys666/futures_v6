#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
JM_SUPPLY_MINE_RATE - 矿山开工率
factor_code: JM_SUPPLY_MINE_RATE
# 付费来源: Mysteel(年费) - 煤矿开工率数据
手动输入兜底脚本
"""

import sys, os as _os
sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), ".."))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value

FACTOR_CODE = "JM_SUPPLY_MINE_RATE"
SYMBOL = "JM"
# 付费来源: Mysteel(年费)

def fetch_value():
    print("[L1-L3] 矿山开工率需Mysteel订阅，无免费替代")
    print("[L4] DB历史回补...")
    val = get_latest_value(FACTOR_CODE, SYMBOL)
    if val is not None:
        print(f"[L4] 兜底: {val}")
        return val, 'db_回补', 0.5
    if '--manual' in sys.argv:
        try:
            v = float(input("请输入矿山开工率(%): "))
            return v, '手动输入', 0.6
        except (ValueError, EOFError):
            pass
    return None, None, None

if __name__ == "__main__":
    pub_date, obs_date = get_pit_dates()
    if pub_date is None:
        print("非交易日，跳过"); exit(0)
    ensure_table()
    print(f"=== {FACTOR_CODE} === pub={pub_date} obs={obs_date}")
    value, source, confidence = fetch_value()
    if value is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, value, source_confidence=confidence, source=source)
    else:
        print(f"[跳过] {FACTOR_CODE} 需付费数据，使用 --manual 手动输入")
