#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
J Mysteel焦炭现货价格
J_J_SPT_MYSTEEEL

数据源:
  - L1: Mysteel网站 (公开可爬，不需要账号)
  - L2: AKShare futures_spot_price(vars_list=['J']) near_contract_price (替代方案)
  - L4: DB历史回补

备注: Mysteel数据公开可爬，此处优先尝试Mysteel，失败则用AKShare替代
"""
import sys, os as _os
sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), ".."))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value

import akshare as ak
import requests
import pandas as pd
from datetime import timedelta

FACTOR_CODE = "J_J_SPT_MYSTEEEL"
SYMBOL = "J"

def fetch_mysteel_price():
    url = "https://index.mysteel.com/api/market/price/getMarketPrice.html?itemCode=13570276448&date="
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': 'https://index.mysteel.com/',
        'Accept': 'application/json, text/plain, */*'
    }
    try:
        resp = requests.get(url, headers=headers, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            if isinstance(data, dict) and 'data' in data:
                price = float(data['data'].get('price', 0))
                if price > 0:
                    print(f"[L1] Mysteel coke price: {price}")
                    return price, 'mysteel_public', 1.0
    except Exception as e:
        print(f"[L1] Mysteel failed: {e}")
    return None, None, None

def fetch_spot_price(obs_date):
    for delta in range(8):
        check = obs_date - timedelta(days=delta)
        if check.weekday() >= 5:
            continue
        date_str = check.strftime('%Y%m%d')
        try:
            df = ak.futures_spot_price(date=date_str, vars_list=['J'])
            if df is None or df.empty:
                continue
            row = df.iloc[-1]
            spot = float(row.get("near_contract_price") or row.get("spot_price") or 0)
            if spot > 0:
                print(f"[L2] AKShare J spot({date_str}): {spot}")
                return spot, check
        except Exception as e:
            print(f"[L2] AKShare J spot({date_str}): {e}")
    return None, None

if __name__ == "__main__":
    pub_date, obs_date = get_pit_dates()
    ensure_table()
    print(f"=== {FACTOR_CODE} === pub={pub_date} obs={obs_date}")
    
    price, source, conf = fetch_mysteel_price()
    actual_date = obs_date
    
    if price is None:
        price, actual_date = fetch_spot_price(obs_date)
        if price is not None:
            source = 'akshare_futures_spot_price(alternative)'
            conf = 0.8
    
    if price is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, actual_date, price, source_confidence=conf, source=source)
        print(f"[OK] {FACTOR_CODE}={price:.2f} written")
    else:
        val = get_latest_value(FACTOR_CODE, SYMBOL)
        if val is not None:
            save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, val, source_confidence=0.5, source='db_fallback')
            print(f"[OK] {FACTOR_CODE}={val} L4 fallback OK")
        else:
            print(f"[FAIL] {FACTOR_CODE} all sources failed")
