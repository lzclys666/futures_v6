#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
J 焦炭出口价格(FOB)
J_J_FOB_EXPORT

数据源:
  - L1: 无免费数据源 (汾渭/海关总署需查阅)
  - L4: DB历史回补

备注: 焦炭出口FOB价暂无免费数据源
"""
import sys, os as _os
sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), ".."))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value

FACTOR_CODE = "J_J_FOB_EXPORT"
SYMBOL = "J"

def fetch_fob_export():
    print("[NOTE] Coke export FOB price has no free data source")
    print("[L4] DB history fallback...")
    val = get_latest_value(FACTOR_CODE, SYMBOL)
    if val is not None:
        print(f"[L4] Fallback: {val}")
        return val, 'db_fallback', 0.5
    return None, None, None

if __name__ == "__main__":
    pub_date, obs_date = get_pit_dates()
    ensure_table()
    print(f"=== {FACTOR_CODE} === pub={pub_date} obs={obs_date}")
    value, source, confidence = fetch_fob_export()
    if value is not None:
        save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, value, source_confidence=confidence, source=source)
    else:
        print(f"[SKIP] {FACTOR_CODE} no history to fall back to")
