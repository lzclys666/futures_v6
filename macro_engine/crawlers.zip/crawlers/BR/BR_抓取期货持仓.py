#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""BR_抓取期货持仓.py"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value
import akshare as ak

SYMBOL = "BR"

def main():
    import argparse
    ensure_table()
    pub_date, obs_date = get_pit_dates()
    print("(auto) === BR持仓 === obs={}".format(obs_date))
    try:
        df = ak.futures_main_sina(symbol="BR0")
        if df is not None and len(df) > 0:
            col_map = {str(c).strip(): c for c in df.columns}
            if "持仓量" in col_map:
                val = float(df.iloc[-1][col_map["持仓量"]])
                save_to_db("BR_POS_NET", SYMBOL, pub_date, obs_date, val, source_confidence=1.0, source="akshare_futures_main_sina")
                print("✅ BR_POS_NET={} 写入成功".format(val))
                return
    except Exception as e:
        print("[L1] 失败: {}".format(e))
    v = get_latest_value("BR_POS_NET", SYMBOL)
    if v is not None:
        save_to_db("BR_POS_NET", SYMBOL, pub_date, obs_date, v, source_confidence=0.5, source="db_回补")
        print("✅ BR_POS_NET={} L4回补成功".format(v))

if __name__ == "__main__":
    main()
