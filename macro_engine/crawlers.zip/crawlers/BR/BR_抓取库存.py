#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""BR_抓取库存.py"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.db_utils import ensure_table, save_to_db, get_pit_dates, get_latest_value
import akshare as ak

SYMBOL = "BR"

def main():
    import argparse
    ensure_table()
    pub_date, obs_date = get_pit_dates()
    print("(auto) === BR库存 === obs={}".format(obs_date))
    try:
        df = ak.futures_inventory_em(symbol="沥青")
        if df is not None and len(df) > 0:
            val = float(df.iloc[-1].iloc[1])
            save_to_db("BR_INV_TOTAL", SYMBOL, pub_date, obs_date, val, source_confidence=1.0, source="akshare_futures_inventory_em")
            print("✅ BR_INV_TOTAL={} 写入成功".format(val))
            return
    except Exception as e:
        print("[L1] 失败: {}".format(e))
    v = get_latest_value("BR_INV_TOTAL", SYMBOL)
    if v is not None:
        save_to_db("BR_INV_TOTAL", SYMBOL, pub_date, obs_date, v, source_confidence=0.5, source="db_回补")
        print("✅ BR_INV_TOTAL={} L4回补成功".format(v))

if __name__ == "__main__":
    main()
