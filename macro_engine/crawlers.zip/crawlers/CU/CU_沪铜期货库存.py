# CU_DCE_INV: 沪铜DCE库存 (SHFE WRT失效替代)
import sys, os, datetime
sys.path.insert(0, 'd:/futures_v6/macro_engine/crawlers/common')
from db_utils import save_to_db, get_latest_value
import akshare as ak
import pandas as pd

FCODE = "CU_DCE_INV"
SYM = "CU"
EMIN = 50000
EMAX = 500000

def fetch():
    # futures_inventory_em DCE库存
    df = ak.futures_inventory_em(symbol='cu')
    if df.empty:
        raise ValueError("CU DCE inv no data")
    latest = df.sort_values(df.columns[0]).iloc[-1]
    raw_value = float(latest.iloc[1])
    obs_date = pd.to_datetime(latest.iloc[0]).date()
    return raw_value, obs_date

def main():
    try:
        raw_value, obs_date = fetch()
    except Exception as e:
        print("[L1] " + FCODE + ": " + str(e))
        latest = get_latest_value(FCODE, SYM)
        if latest is not None:
            print("[L4] " + FCODE + "=" + str(latest))
        else:
            print("[SKIP] " + FCODE)
        return
    if not (EMIN <= raw_value <= EMAX):
        print("[WARN] " + FCODE + "=" + str(raw_value) + " [" + str(EMIN) + "," + str(EMAX) + "]")
        return
    save_to_db(FCODE, SYM, datetime.date.today(), obs_date, raw_value, source_confidence=0.9)
    print("[OK] " + FCODE + "=" + str(raw_value) + " obs=" + str(obs_date))

if __name__ == "__main__":
    main()
