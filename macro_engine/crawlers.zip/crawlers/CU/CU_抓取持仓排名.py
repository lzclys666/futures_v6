# -*- coding: utf-8 -*-
"""
CU_POS_NET: 沪铜持仓净多 (SHFE Copper Net Long Position of Top Traders)
数据源: AKShare get_shfe_rank_table(date, vars_list=['CU'])
频率: 日度
计算: 主力合约多头总持仓 - 空头总持仓
实测2026-04-17: cu2605为主力合约, 多头=..., 空头=..., 净多=...
列名: long_open_interest, short_open_interest
"""
import sys, os
this_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(this_dir, '..', 'common'))
from db_utils import save_to_db, get_latest_value
import akshare as ak
from datetime import date, timedelta

FACTOR_CODE = "CU_POS_NET"
SYMBOL = "CU"
EXPECTED_MIN = -200000
EXPECTED_MAX = 200000

def get_last_trading_day():
    today = date.today()
    for days_back in range(30):
        d = today - timedelta(days=days_back)
        if d.weekday() < 5:
            return d
    return today

def fetch():
    obs_date = get_last_trading_day()
    date_str = obs_date.strftime('%Y%m%d')
    r = ak.get_shfe_rank_table(date=date_str, vars_list=['CU'])
    if not r:
        raise ValueError("SHFE CU持仓排名返回空 date=%s" % date_str)
    # 取主力合约(持仓量最大的合约)
    contracts = {k: v for k, v in r.items() if str(k).startswith('cu')}
    if not contracts:
        raise ValueError("无CU合约数据 keys=%s" % list(r.keys()))
    # 取总持仓量最大的合约作为主力
    main_contract = max(contracts.keys(), key=lambda k: float(contracts[k]['long_open_interest'].sum()) + float(contracts[k]['short_open_interest'].sum()))
    df = contracts[main_contract]
    long_sum = float(df['long_open_interest'].sum())
    short_sum = float(df['short_open_interest'].sum())
    raw_value = long_sum - short_sum
    return raw_value, obs_date

def main():
    try:
        raw_value, obs_date = fetch()
    except Exception as e:
        print("[L1 FAIL] %s: %s" % (FACTOR_CODE, e))
        latest = get_latest_value(FACTOR_CODE, SYMBOL)
        if latest is not None:
            print("[L4 Fallback] %s=%.2f" % (FACTOR_CODE, latest))
            return
        print("[L4 SKIP] %s: no data" % FACTOR_CODE)
        return

    if not (EXPECTED_MIN <= raw_value <= EXPECTED_MAX):
        print("[WARN] %s=%.1f out of [%d,%d]" % (FACTOR_CODE, raw_value, EXPECTED_MIN, EXPECTED_MAX))
        return

    pub_date = date.today()
    save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, raw_value, source_confidence=1.0)
    print("[OK] %s=%.1f obs=%s" % (FACTOR_CODE, raw_value, obs_date))

if __name__ == "__main__":
    main()
