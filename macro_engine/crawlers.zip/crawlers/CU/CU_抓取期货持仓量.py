# -*- coding: utf-8 -*-
"""
CU_FUT_OI: 沪铜期货持仓量 (SHFE Copper Futures Open Interest)
数据源: AKShare futures_main_sina(symbol="cu0")
频率: 日度
字段: 持仓量(手)，主力合约为cu0
实测2026-04-17: 持仓量=176222手
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'common'))
from db_utils import save_to_db, get_latest_value
import akshare as ak
from datetime import date

FACTOR_CODE = "CU_FUT_OI"
SYMBOL = "CU"
EXPECTED_MIN = 50000
EXPECTED_MAX = 500000

def fetch():
    df = ak.futures_main_sina(symbol="cu0")
    df['日期'] = pd.to_datetime(df['日期']).dt.date
    latest = df.sort_values('日期').iloc[-1]
    raw_value = float(latest['持仓量'])
    obs_date = latest['日期']
    return raw_value, obs_date

def main():
    try:
        raw_value, obs_date = fetch()
    except Exception as e:
        print(f"[L1 FAIL] {FACTOR_CODE}: {e}")
        latest = get_latest_value(FACTOR_CODE, SYMBOL)
        if latest is not None:
            print(f"[L4 Fallback] {FACTOR_CODE}={latest}")
            return
        print(f"[L4 SKIP] {FACTOR_CODE}: no data")
        return

    if not (EXPECTED_MIN <= raw_value <= EXPECTED_MAX):
        print(f"[WARN] {FACTOR_CODE}={raw_value} out of [{EXPECTED_MIN},{EXPECTED_MAX}]")
        return

    pub_date = date.today()
    save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, raw_value, source_confidence=1.0)
    print(f"[OK] {FACTOR_CODE}={raw_value} obs={obs_date}")

if __name__ == "__main__":
    import pandas as pd
    main()
