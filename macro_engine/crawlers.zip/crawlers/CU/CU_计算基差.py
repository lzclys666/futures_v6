# -*- coding: utf-8 -*-
"""
CU_SPD_BASIS: 沪铜期现基差 (SHFE Copper Spot-Futures Basis)
数据源: AKShare futures_spot_price(date, vars_list=['CU'])
频率: 日度
说明: near_basis = spot_price - near_contract_price (现货-近月期货)
      near_basis_rate = near_basis / near_contract_price
实测2026-04-18: spot_price=76328.33, near_contract_price=76220, near_basis=-108.33
AKShare的spot_price是现货价，near_contract_price是近月期货价
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'common'))
from db_utils import save_to_db, get_latest_value
import akshare as ak
from datetime import date, timedelta

FACTOR_CODE = "CU_SPD_BASIS"
SYMBOL = "CU"
EXPECTED_MIN = -500
EXPECTED_MAX = 500

def get_last_trading_day():
    today = date.today()
    for days_back in range(7):
        d = today - timedelta(days=days_back)
        if d.weekday() < 5:  # Mon-Fri
            return d
    return today

def fetch():
    obs_date = get_last_trading_day()
    date_str = obs_date.strftime('%Y%m%d')
    df = ak.futures_spot_price(date=date_str, vars_list=['CU'])
    if df.empty:
        raise ValueError(f"CU现货价返回空数据 date={date_str}")
    row = df.iloc[0]
    raw_value = float(row['near_basis'])
    return raw_value, obs_date

def main():
    try:
        raw_value, obs_date = fetch()
    except Exception as e:
        print(f"[L1 FAIL] {FACTOR_CODE}: {e}")
        # L4: 历史回补
        latest = get_latest_value(FACTOR_CODE, SYMBOL)
        if latest is not None:
            print(f"[L4 Fallback] {FACTOR_CODE}={latest}")
            return
        print(f"[L4 SKIP] {FACTOR_CODE}: no data")
        return

    if not (EXPECTED_MIN <= raw_value <= EXPECTED_MAX):
        print(f"[WARN] {FACTOR_CODE}={raw_value} out of [{EXPECTED_MIN},{EXPECTED_MAX}], check")
        return

    pub_date = date.today()
    save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, raw_value, source_confidence=1.0)
    print(f"[OK] {FACTOR_CODE}={raw_value} obs={obs_date}")

if __name__ == "__main__":
    main()
