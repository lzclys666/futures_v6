# -*- coding: utf-8 -*-
"""
CU_INV_LME: LME铜库存 (LME Copper Warehouse Stocks)
数据源: AKShare macro_euro_lme_stock() (无symbol参数，返回所有LME金属库存)
频率: 日度
字段: 铜-库存 (吨)，另含铜-注册仓单、铜-注销仓单
实测2026-04-17: 铜-库存=400225吨，铜-注册仓单=348450吨，铜-注销仓单=51775吨
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'common'))
from db_utils import save_to_db, get_latest_value
import akshare as ak
from datetime import date

FACTOR_CODE = "CU_INV_LME"
SYMBOL = "CU"
EXPECTED_MIN = 100000
EXPECTED_MAX = 800000

def fetch():
    df = ak.macro_euro_lme_stock()
    df['日期'] = pd.to_datetime(df['日期']).dt.date
    latest = df.sort_values('日期').iloc[-1]
    raw_value = float(latest['铜-库存'])
    obs_date = latest['日期']
    return raw_value, obs_date

def main():
    try:
        raw_value, obs_date = fetch()
    except Exception as e:
        print(f"[L1 FAIL] {FACTOR_CODE}: {e}")
        latest = get_latest_value(FACTOR_CODE, SYMBOL)
        if latest is not None:
            print(f"[L4 Fallback] {FACTOR_CODE}={latest}")
            return
        print(f"[L4 SKIP] {FACTOR_CODE}: no data")
        return

    if not (EXPECTED_MIN <= raw_value <= EXPECTED_MAX):
        print(f"[WARN] {FACTOR_CODE}={raw_value} out of [{EXPECTED_MIN},{EXPECTED_MAX}]")
        return

    pub_date = date.today()
    save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, raw_value, source_confidence=1.0)
    print(f"[OK] {FACTOR_CODE}={raw_value} obs={obs_date}")

if __name__ == "__main__":
    import pandas as pd
    main()
