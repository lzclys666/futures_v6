# AO_DCE_INV: ao DCE inventory
import sys, os, datetime
sys.path.insert(0, 'd:/futures_v6/macro_engine/crawlers/common')
from db_utils import save_to_db, get_latest_value
import akshare as ak
import pandas as pd

FCODE = "AO_DCE_INV"
SYM = "AO"
EMIN = 200000
EMAX = 1000000

def fetch():
    df = ak.futures_inventory_em(symbol='ao')
    if df.empty:
        raise ValueError("no data")
    latest = df.sort_values(df.columns[0]).iloc[-1]
    raw_value = float(latest.iloc[1])
    obs_date = pd.to_datetime(latest.iloc[0]).date()
    return raw_value, obs_date

def main():
    try:
        raw_value, obs_date = fetch()
    except Exception as e:
        print("[L1] " + FCODE + ": " + str(e))
        latest = get_latest_value(FCODE, SYM)
        if latest is not None:
            print("[L4] " + FCODE + "=" + str(latest))
        else:
            print("[SKIP] " + FCODE)
        return
    if not (EMIN <= raw_value <= EMAX):
        print("[WARN] " + FCODE + "=" + str(raw_value) + " [" + str(EMIN) + "," + str(EMAX) + "]")
        return
    save_to_db(FCODE, SYM, datetime.date.today(), obs_date, raw_value, source_confidence=1.0)
    print("[OK] " + FCODE + "=" + str(raw_value) + " obs=" + str(obs_date))

if __name__ == "__main__":
    main()
