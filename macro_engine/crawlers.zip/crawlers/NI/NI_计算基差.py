# -*- coding: utf-8 -*-
"""
NI_SPD_BASIS: 沪镍期现基差
数据源: AKShare futures_spot_price(vars_list=["NI"])
频率: 日度
注意: spot_price数据滞后（实测20240430=144166元/吨，约2年前）
实测: near_basis=-1306.67, near_basis_rate=-0.0091
"""
import sys, os
this_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(this_dir, '..', 'common'))
from db_utils import save_to_db, get_latest_value
import akshare as ak
from datetime import date, timedelta
import pandas as pd

FACTOR_CODE = "NI_SPD_BASIS"
SYMBOL = "NI"
EXPECTED_MIN = -3000
EXPECTED_MAX = 3000
STALE_DAYS = 30

def fetch():
    df = ak.futures_spot_price(vars_list=["NI"])
    if df.empty:
        raise ValueError("AKShare无NI期现基差数据")
    latest = df.sort_values('date').iloc[-1]
    raw_value = float(latest['near_basis'])
    obs_date = pd.to_datetime(latest['date']).date()
    return raw_value, obs_date

def main():
    try:
        raw_value, obs_date = fetch()
    except Exception as e:
        print("[L1 FAIL] %s: %s" % (FACTOR_CODE, e))
        latest = get_latest_value(FACTOR_CODE, SYMBOL)
        if latest is not None:
            print("[L4 Fallback] %s=%.1f" % (FACTOR_CODE, latest))
            return
        print("[L4 SKIP] %s: no data" % FACTOR_CODE)
        return

    days_old = (date.today() - obs_date).days
    if days_old > STALE_DAYS:
        print("[WARN] %s=%.1f obs=%s (滞后%d天)" % (FACTOR_CODE, raw_value, obs_date, days_old))
        save_to_db(FACTOR_CODE, SYMBOL, date.today(), obs_date, raw_value, source_confidence=0.6)
        return

    if not (EXPECTED_MIN <= raw_value <= EXPECTED_MAX):
        print("[WARN] %s=%.1f out of [%d,%d]" % (FACTOR_CODE, raw_value, EXPECTED_MIN, EXPECTED_MAX))
        return

    pub_date = date.today()
    save_to_db(FACTOR_CODE, SYMBOL, pub_date, obs_date, raw_value, source_confidence=1.0)
    print("[OK] %s=%.1f obs=%s" % (FACTOR_CODE, raw_value, obs_date))

if __name__ == "__main__":
    main()
